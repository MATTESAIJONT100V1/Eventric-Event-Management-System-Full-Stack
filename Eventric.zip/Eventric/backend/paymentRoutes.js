
const express = require("express");
const router = express.Router();

const db = require("../db");
const jwt = require("jsonwebtoken");

console.log("PAYMENT ROUTES LOADED");


// ======================================
// AUTHENTICATION MIDDLEWARE
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];

    const token =
        authHeader &&
        authHeader.split(" ")[1];


    if (!token) {

        return res.status(401).json({
            message:
                "Please login first"
        });

    }


    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({
                    message:
                        "Invalid or expired token"
                });

            }


            req.user = user;

            next();

        }
    );

}


// ======================================
// TEST PAYMENT ROUTE
// ======================================

router.get(
    "/test",
    (req, res) => {

        res.json({
            message:
                "Payment route is working!"
        });

    }
);


// ======================================
// CREATE PAYMENT
// ======================================

router.post(
    "/",
    authenticateToken,
    (req, res) => {

        const userId =
            req.user.id;


        const {
            booking_id,
            payment_method
        } = req.body;


        // ======================================
        // CHECK INPUT
        // ======================================

        if (
            !booking_id ||
            !payment_method
        ) {

            return res.status(400).json({
                message:
                    "Booking ID and payment method are required"
            });

        }


        // ======================================
        // GET BOOKING
        // ======================================

        const bookingSql = `
            SELECT
                bookings.id,
                bookings.user_id,
                bookings.event_id,
                bookings.quantity,
                bookings.total_amount,
                bookings.booking_status,

                events.title

            FROM bookings

            INNER JOIN events
                ON bookings.event_id = events.id

            WHERE bookings.id = ?
            AND bookings.user_id = ?
        `;


        db.query(
            bookingSql,
            [
                booking_id,
                userId
            ],
            (err, bookings) => {

                if (err) {

                    console.error(
                        "BOOKING QUERY ERROR:",
                        err
                    );

                    return res.status(500).json({
                        message:
                            "Database error"
                    });

                }


                // ======================================
                // BOOKING NOT FOUND
                // ======================================

                if (
                    bookings.length === 0
                ) {

                    return res.status(404).json({
                        message:
                            "Booking not found"
                    });

                }


                const booking =
                    bookings[0];


                // ======================================
                // CHECK BOOKING STATUS
                // ======================================

                if (
                    booking.booking_status !==
                    "pending"
                ) {

                    return res.status(400).json({
                        message:
                            "This booking has already been processed"
                    });

                }


                // ======================================
                // GENERATE TRANSACTION ID
                // ======================================

                const transactionId =
                    "TXN-" +
                    Date.now() +
                    "-" +
                    Math.floor(
                        Math.random() * 10000
                    );


                // ======================================
                // START TRANSACTION
                // ======================================

                db.beginTransaction(
                    (transactionError) => {

                        if (transactionError) {

                            console.error(
                                "TRANSACTION START ERROR:",
                                transactionError
                            );

                            return res.status(500).json({
                                message:
                                    "Failed to start payment transaction"
                            });

                        }


                        // ======================================
                        // INSERT PAYMENT
                        // ======================================

                        const paymentSql = `
                            INSERT INTO payments
                            (
                                booking_id,
                                payment_method,
                                transaction_id,
                                amount,
                                payment_status
                            )
                            VALUES (?, ?, ?, ?, 'successful')
                        `;


                        db.query(
                            paymentSql,
                            [
                                booking.id,
                                payment_method,
                                transactionId,
                                booking.total_amount
                            ],
                            (err, paymentResult) => {

                                if (err) {

                                    console.error(
                                        "PAYMENT INSERT ERROR:",
                                        err
                                    );

                                    return db.rollback(
                                        () => {

                                            res.status(500).json({
                                                message:
                                                    "Failed to create payment"
                                            });

                                        }
                                    );

                                }


                                // ======================================
                                // UPDATE BOOKING
                                // ======================================

                                const updateBookingSql = `
                                    UPDATE bookings
                                    SET booking_status = 'confirmed'
                                    WHERE id = ?
                                    AND user_id = ?
                                `;


                                db.query(
                                    updateBookingSql,
                                    [
                                        booking.id,
                                        userId
                                    ],
                                    (err, bookingResult) => {

                                        if (err) {

                                            console.error(
                                                "BOOKING UPDATE ERROR:",
                                                err
                                            );

                                            return db.rollback(
                                                () => {

                                                    res.status(500).json({
                                                        message:
                                                            "Failed to confirm booking"
                                                    });

                                                }
                                            );

                                        }


                                        if (
                                            bookingResult.affectedRows === 0
                                        ) {

                                            return db.rollback(
                                                () => {

                                                    res.status(400).json({
                                                        message:
                                                            "Booking could not be confirmed"
                                                    });

                                                }
                                            );

                                        }


                                        // ======================================
                                        // COMMIT PAYMENT
                                        // ======================================

                                        db.commit(
                                            (commitError) => {

                                                if (commitError) {

                                                    console.error(
                                                        "PAYMENT COMMIT ERROR:",
                                                        commitError
                                                    );

                                                    return db.rollback(
                                                        () => {

                                                            res.status(500).json({
                                                                message:
                                                                    "Payment could not be completed"
                                                            });

                                                        }
                                                    );

                                                }


                                                // ======================================
                                                // PAYMENT SUCCESS
                                                // ======================================

                                                res.status(201).json({

                                                    message:
                                                        "Payment successful. Booking confirmed.",

                                                    paymentId:
                                                        paymentResult.insertId,

                                                    transactionId:
                                                        transactionId,

                                                    bookingId:
                                                        booking.id,

                                                    bookingStatus:
                                                        "confirmed",

                                                    paymentStatus:
                                                        "successful"

                                                });

                                            }
                                        );

                                    }
                                );

                            }
                        );

                    }
                );

            }
        );

    }
);


// ======================================
// EXPORT ROUTER
// ======================================

module.exports = router;

