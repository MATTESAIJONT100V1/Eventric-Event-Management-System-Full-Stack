const jwt = require("jsonwebtoken");


// ======================================
// AUTHENTICATION MIDDLEWARE
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];


    if (!authHeader) {

        return res.status(401).json({
            message: "Access token required"
        });

    }


    const token =
        authHeader.split(" ")[1];


    if (!token) {

        return res.status(401).json({
            message: "Invalid authorization format"
        });

    }


    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({
                    message: "Invalid or expired token"
                });

            }


            req.user = user;

            next();

        }
    );

}


module.exports =
    authenticateToken;