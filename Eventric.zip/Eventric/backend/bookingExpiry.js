
const db = require("./db");


// ======================================
// PENDING BOOKING EXPIRATION
// ======================================

const EXPIRY_MINUTES = 15;


// ======================================
// EXPIRE OLD BOOKINGS
// ======================================

async function expirePendingBookings() {

    try {

        // Find pending bookings older than 15 minutes
        const [bookings] = await db.promise().query(
            `
            SELECT id, event_id, quantity
            FROM bookings
            WHERE booking_status = 'pending'
            AND booking_date < DATE_SUB(
                NOW(),
                INTERVAL ? MINUTE
            )
            `,
            [EXPIRY_MINUTES]
        );


        // No expired bookings
        if (bookings.length === 0) {
            return;
        }


        console.log(
            `Found ${bookings.length} expired booking(s).`
        );


        // Process bookings one by one
        for (const booking of bookings) {

            try {

                // Start transaction
                await db.promise().beginTransaction();


                // Check booking again
                // Only process if still pending
                const [bookingRows] =
                    await db.promise().query(
                        `
                        SELECT id, event_id, quantity
                        FROM bookings
                        WHERE id = ?
                        AND booking_status = 'pending'
                        FOR UPDATE
                        `,
                        [booking.id]
                    );


                // Booking already processed
                if (bookingRows.length === 0) {

                    await db.promise().rollback();

                    continue;
                }


                const currentBooking =
                    bookingRows[0];


                // ======================================
                // RETURN SEATS
                // ======================================

                await db.promise().query(
                    `
                    UPDATE events
                    SET available_seats =
                        available_seats + ?
                    WHERE id = ?
                    `,
                    [
                        currentBooking.quantity,
                        currentBooking.event_id
                    ]
                );


                // ======================================
                // CANCEL BOOKING
                // ======================================

                await db.promise().query(
                    `
                    UPDATE bookings
                    SET booking_status = 'cancelled'
                    WHERE id = ?
                    AND booking_status = 'pending'
                    `,
                    [currentBooking.id]
                );


                // Commit transaction
                await db.promise().commit();


                console.log(
                    `Booking #${currentBooking.id} expired. ` +
                    `${currentBooking.quantity} seat(s) returned.`
                );


            } catch (error) {

                // Rollback if something fails
                try {
                    await db.promise().rollback();
                } catch (rollbackError) {
                    console.error(
                        "Rollback error:",
                        rollbackError.message
                    );
                }


                console.error(
                    `Failed to expire booking #${booking.id}:`,
                    error.message
                );
            }
        }


    } catch (error) {

        console.error(
            "Booking expiration error:",
            error.message
        );
    }
}


// ======================================
// RUN EVERY 1 MINUTE
// ======================================

setInterval(
    expirePendingBookings,
    60 * 1000
);


// ======================================
// RUN WHEN SERVER STARTS
// ======================================

expirePendingBookings();


module.exports = expirePendingBookings;

