const bcrypt = require("bcryptjs");
const db = require("./db");

const newPassword = "Organizer123";

bcrypt.hash(newPassword, 10, (err, hash) => {
    if (err) {
        console.error(err);
        return;
    }

    const sql = `
        UPDATE users
        SET password = ?
        WHERE email = 'organizer@eventric.com'
    `;

    db.query(sql, [hash], (err, result) => {
        if (err) {
            console.error(err);
            return;
        }

        console.log("Organizer password updated successfully!");
        console.log("Email: organizer@eventric.com");
        console.log("Password: Organizer123");

        process.exit();
    });
});