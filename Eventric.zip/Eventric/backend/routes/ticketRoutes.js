
const express = require("express");
const router = express.Router();

const db = require("../db");
const jwt = require("jsonwebtoken");


// ======================================
// AUTHENTICATION MIDDLEWARE
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];

    const token =
        authHeader &&
        authHeader.split(" ")[1];


    if (!token) {

        return res.status(401).json({

            message:
                "Please login first"

        });

    }


    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({

                    message:
                        "Invalid or expired token"

                });

            }


            req.user = user;

            next();

        }
    );

}


// ======================================
// ORGANIZER / ADMIN CHECK
// ======================================

function checkOrganizerOrAdmin(
    req,
    res,
    next
) {

    if (!req.user) {

        return res.status(401).json({

            message:
                "Authentication required"

        });

    }


    const role =
        String(req.user.role || "")
            .trim()
            .toLowerCase();


    if (
        role !== "organizer" &&
        role !== "admin"
    ) {

        return res.status(403).json({

            message:
                "Only organizers and admins can verify tickets"

        });

    }


    next();

}


// ======================================
// TEST TICKET ROUTE
// ======================================

router.get(
    "/test",
    (req, res) => {

        res.json({

            message:
                "Ticket route is working!"

        });

    }
);


// ======================================
// VERIFY TICKET BY TICKET CODE
// ORGANIZER / ADMIN ONLY
// ======================================

router.get(
    "/verify/:ticketCode",

    authenticateToken,

    checkOrganizerOrAdmin,

    (req, res) => {

        const ticketCode =
            req.params.ticketCode;


        if (!ticketCode) {

            return res.status(400).json({

                message:
                    "Ticket code is required"

            });

        }


        const sql = `

            SELECT

                tickets.id AS ticket_id,

                tickets.ticket_code,


                bookings.id AS booking_id,

                bookings.quantity,

                bookings.total_amount,

                bookings.booking_status,


                events.id AS event_id,

                events.title,

                events.description,

                events.category,

                events.event_date,

                events.event_time,

                events.venue,


                payments.payment_status,

                payments.payment_method,

                payments.transaction_id,

                payments.payment_date


            FROM tickets


            INNER JOIN bookings
                ON tickets.booking_id =
                   bookings.id


            INNER JOIN events
                ON bookings.event_id =
                   events.id


            LEFT JOIN payments
                ON bookings.id =
                   payments.booking_id


            WHERE tickets.ticket_code = ?

            LIMIT 1

        `;


        db.query(
            sql,
            [ticketCode],
            (err, results) => {


                // ======================================
                // DATABASE ERROR
                // ======================================

                if (err) {

                    console.error(err);

                    return res.status(500).json({

                        message:
                            "Failed to verify ticket"

                    });

                }


                // ======================================
                // TICKET NOT FOUND
                // ======================================

                if (results.length === 0) {

                    return res.status(404).json({

                        message:
                            "Invalid or non-existent ticket"

                    });

                }


                const ticket =
                    results[0];


                // ======================================
                // CHECK BOOKING STATUS
                // ======================================

                if (

                    String(
                        ticket.booking_status || ""
                    )
                        .trim()
                        .toLowerCase() !==
                    "confirmed"

                ) {

                    return res.status(400).json({

                        valid: false,

                        message:
                            "Ticket is not confirmed",

                        ticket_code:
                            ticket.ticket_code

                    });

                }


                // ======================================
                // CHECK PAYMENT STATUS
                // ======================================

                if (

                    ticket.payment_status &&

                    String(
                        ticket.payment_status
                    )
                        .trim()
                        .toLowerCase() !==
                    "successful"

                ) {

                    return res.status(400).json({

                        valid: false,

                        message:
                            "Ticket payment is not completed",

                        ticket_code:
                            ticket.ticket_code

                    });

                }


                // ======================================
                // VALID TICKET
                // ======================================

                return res.json({

                    valid: true,


                    ticket_id:
                        ticket.ticket_id,


                    ticket_code:
                        ticket.ticket_code,


                    booking_id:
                        ticket.booking_id,


                    title:
                        ticket.title,


                    description:
                        ticket.description,


                    category:
                        ticket.category,


                    event_date:
                        ticket.event_date,


                    event_time:
                        ticket.event_time,


                    venue:
                        ticket.venue,


                    quantity:
                        ticket.quantity,


                    total_amount:
                        ticket.total_amount,


                    booking_status:
                        ticket.booking_status,


                    payment_status:
                        ticket.payment_status,


                    payment_method:
                        ticket.payment_method,


                    transaction_id:
                        ticket.transaction_id,


                    payment_date:
                        ticket.payment_date

                });

            }
        );

    }
);


// ======================================
// GET TICKET BY BOOKING ID
// LOGGED-IN USER'S OWN TICKET
// ======================================

router.get(
    "/:bookingId",

    authenticateToken,

    (req, res) => {

        const bookingId =
            req.params.bookingId;


        const userId =
            req.user.id;


        const sql = `

            SELECT

                tickets.id AS ticket_id,

                tickets.ticket_code,


                bookings.id AS booking_id,

                bookings.quantity,

                bookings.total_amount,

                bookings.booking_status,


                events.id AS event_id,

                events.title,

                events.description,

                events.category,

                events.event_date,

                events.event_time,

                events.venue,


                payments.payment_status,

                payments.payment_method,

                payments.transaction_id,

                payments.payment_date


            FROM tickets


            INNER JOIN bookings
                ON tickets.booking_id =
                   bookings.id


            INNER JOIN events
                ON bookings.event_id =
                   events.id


            LEFT JOIN payments
                ON bookings.id =
                   payments.booking_id


            WHERE tickets.booking_id = ?

            AND bookings.user_id = ?

            LIMIT 1

        `;


        db.query(
            sql,
            [
                bookingId,
                userId
            ],
            (err, results) => {


                // ======================================
                // DATABASE ERROR
                // ======================================

                if (err) {

                    console.error(err);

                    return res.status(500).json({

                        message:
                            "Failed to fetch ticket"

                    });

                }


                // ======================================
                // TICKET NOT FOUND
                // ======================================

                if (results.length === 0) {

                    return res.status(404).json({

                        message:
                            "Ticket not found"

                    });

                }


                // ======================================
                // RETURN TICKET
                // ======================================

                return res.json(
                    results[0]
                );

            }
        );

    }
);


// ======================================
// EXPORT ROUTER
// ======================================
module.exports = router;


