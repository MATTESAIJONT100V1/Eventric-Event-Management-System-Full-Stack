const express = require("express");
const router = express.Router();

const db = require("../db");
const jwt = require("jsonwebtoken");


// ======================================
// AUTHENTICATION
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];

    const token =
        authHeader &&
        authHeader.split(" ")[1];

    if (!token) {

        return res.status(401).json({
            message: "Please login first"
        });

    }

    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({
                    message:
                        "Invalid or expired token"
                });

            }

            req.user = user;

            next();

        }
    );

}


// ======================================
// ADMIN ONLY
// ======================================

function adminOnly(req, res, next) {

    if (
        !req.user ||
        req.user.role !== "admin"
    ) {

        return res.status(403).json({
            message:
                "Admin access required"
        });

    }

    next();

}


// ======================================
// TEST ADMIN ROUTE
// ======================================

router.get(
    "/test",
    authenticateToken,
    adminOnly,
    (req, res) => {

        res.json({
            message:
                "Admin route is working!"
        });

    }
);


// ======================================
// DASHBOARD STATISTICS
// ======================================

router.get(
    "/stats",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT

                (SELECT COUNT(*)
                 FROM users)
                AS total_users,

                (SELECT COUNT(*)
                 FROM events)
                AS total_events,

                (SELECT COUNT(*)
                 FROM bookings)
                AS total_bookings,

                (SELECT COUNT(*)
                 FROM payments)
                AS total_payments,

                (SELECT COUNT(*)
                 FROM tickets)
                AS total_tickets
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load statistics"
                    });

                }

                res.json(results[0]);

            }
        );

    }
);


// ======================================
// GET ALL USERS
// ======================================

router.get(
    "/users",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT
                id,
                name,
                email,
                role,
                created_at
            FROM users
            ORDER BY id DESC
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load users"
                    });

                }

                res.json(results);

            }
        );

    }
);


// ======================================
// CHANGE USER ROLE
// ======================================

router.put(
    "/users/:id/role",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const userId =
            req.params.id;

        const newRole =
            req.body.role;


        // ======================================
        // VALIDATE ROLE
        // ======================================

        if (
            newRole !== "user" &&
            newRole !== "organizer"
        ) {

            return res.status(400).json({
                message:
                    "Role must be either user or organizer."
            });

        }


        // ======================================
        // PREVENT ADMIN SELF-MODIFICATION
        // ======================================

        if (
            Number(userId) ===
            Number(req.user.id)
        ) {

            return res.status(400).json({
                message:
                    "You cannot change your own role."
            });

        }


        // ======================================
        // FIND USER
        // ======================================

        db.query(
            `
            SELECT
                id,
                name,
                email,
                role
            FROM users
            WHERE id = ?
            `,
            [userId],
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to find user."
                    });

                }


                if (results.length === 0) {

                    return res.status(404).json({
                        message:
                            "User not found."
                    });

                }


                const user =
                    results[0];


                // ======================================
                // PROTECT ADMIN
                // ======================================

                if (
                    user.role === "admin"
                ) {

                    return res.status(400).json({
                        message:
                            "Admin role cannot be changed."
                    });

                }


                // ======================================
                // UPDATE ROLE
                // ======================================

                db.query(
                    `
                    UPDATE users
                    SET role = ?
                    WHERE id = ?
                    `,
                    [
                        newRole,
                        userId
                    ],
                    (updateErr) => {

                        if (updateErr) {

                            console.error(
                                updateErr
                            );

                            return res.status(500).json({
                                message:
                                    "Failed to update user role."
                            });

                        }


                        res.json({

                            message:
                                "User role updated successfully.",

                            userId:
                                user.id,

                            name:
                                user.name,

                            email:
                                user.email,

                            role:
                                newRole

                        });

                    }
                );

            }
        );

    }
);


// ======================================
// DELETE USER
// ======================================

router.delete(
    "/users/:id",
    authenticateToken,
    adminOnly,
    async (req, res) => {

        try {

            const userId =
                req.params.id;


            // ======================================
            // PREVENT ADMIN SELF-DELETION
            // ======================================

            if (
                Number(userId) ===
                Number(req.user.id)
            ) {

                return res.status(400).json({
                    message:
                        "You cannot delete your own admin account."
                });

            }


            // ======================================
            // FIND USER
            // ======================================

            const [users] =
                await db.promise().query(
                    `
                    SELECT
                        id,
                        name,
                        email,
                        role
                    FROM users
                    WHERE id = ?
                    `,
                    [userId]
                );


            if (users.length === 0) {

                return res.status(404).json({
                    message:
                        "User not found."
                });

            }


            const user =
                users[0];


            // ======================================
            // PROTECT ADMIN
            // ======================================

            if (
                user.role === "admin"
            ) {

                return res.status(400).json({
                    message:
                        "Admin account cannot be deleted."
                });

            }


            // ======================================
            // CHECK BOOKINGS
            // ======================================

            const [bookings] =
                await db.promise().query(
                    `
                    SELECT COUNT(*) AS total
                    FROM bookings
                    WHERE user_id = ?
                    `,
                    [userId]
                );


            if (
                bookings[0].total > 0
            ) {

                return res.status(400).json({
                    message:
                        "This user cannot be deleted because they have existing bookings."
                });

            }


            // ======================================
            // CHECK EVENTS
            // ======================================

            const [events] =
                await db.promise().query(
                    `
                    SELECT COUNT(*) AS total
                    FROM events
                    WHERE organizer_id = ?
                    `,
                    [userId]
                );


            if (
                events[0].total > 0
            ) {

                return res.status(400).json({
                    message:
                        "This user cannot be deleted because they have existing events."
                });

            }


            // ======================================
            // DELETE USER
            // ======================================

            await db.promise().query(
                `
                DELETE FROM users
                WHERE id = ?
                `,
                [userId]
            );


            // ======================================
            // SUCCESS
            // ======================================

            res.json({

                message:
                    "User deleted successfully.",

                userId:
                    user.id,

                name:
                    user.name,

                email:
                    user.email

            });

        } catch (error) {

            console.error(
                "DELETE USER ERROR:",
                error
            );

            res.status(500).json({
                message:
                    "Failed to delete user."
            });

        }

    }
);


// ======================================
// GET ALL EVENTS
// ======================================

router.get(
    "/events",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT
                events.*,
                users.name AS organizer_name
            FROM events

            INNER JOIN users
                ON events.organizer_id =
                   users.id

            ORDER BY events.id DESC
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load events"
                    });

                }

                res.json(results);

            }
        );

    }
);


// ======================================
// GET ALL BOOKINGS
// ======================================

router.get(
    "/bookings",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT

                bookings.id,
                bookings.quantity,
                bookings.total_amount,
                bookings.booking_status,
                bookings.booking_date,

                users.name AS user_name,
                users.email AS user_email,

                events.title AS event_title

            FROM bookings

            INNER JOIN users
                ON bookings.user_id =
                   users.id

            INNER JOIN events
                ON bookings.event_id =
                   events.id

            ORDER BY bookings.id DESC
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load bookings"
                    });

                }

                res.json(results);

            }
        );

    }
);


// ======================================
// GET ALL PAYMENTS
// ======================================

router.get(
    "/payments",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT

                payments.id,
                payments.booking_id,
                payments.amount,
                payments.payment_method,
                payments.transaction_id,
                payments.payment_status,
                payments.payment_date,

                users.name AS user_name,
                users.email AS user_email,

                events.title AS event_title

            FROM payments

            INNER JOIN bookings
                ON payments.booking_id =
                   bookings.id

            INNER JOIN users
                ON bookings.user_id =
                   users.id

            INNER JOIN events
                ON bookings.event_id =
                   events.id

            ORDER BY payments.id DESC
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load payments"
                    });

                }

                res.json(results);

            }
        );

    }
);


// ======================================
// GET ALL TICKETS
// ======================================

router.get(
    "/tickets",
    authenticateToken,
    adminOnly,
    (req, res) => {

        const sql = `
            SELECT

                tickets.id,
                tickets.ticket_code,
                tickets.created_at,

                bookings.id AS booking_id,
                bookings.quantity,
                bookings.total_amount,
                bookings.booking_status,

                users.name AS user_name,
                users.email AS user_email,

                events.title AS event_title

            FROM tickets

            INNER JOIN bookings
                ON tickets.booking_id =
                   bookings.id

            INNER JOIN users
                ON bookings.user_id =
                   users.id

            INNER JOIN events
                ON bookings.event_id =
                   events.id

            ORDER BY tickets.id DESC
        `;

        db.query(
            sql,
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to load tickets"
                    });

                }

                res.json(results);

            }
        );

    }
);


module.exports = router;