
const express = require("express");
const router = express.Router();

const db = require("../db");
const jwt = require("jsonwebtoken");

console.log("BOOKING ROUTES LOADED");


// ======================================
// TEST BOOKING ROUTE
// ======================================

router.get("/test", (req, res) => {

    res.json({
        message: "Booking route is working!"
    });

});


// ======================================
// AUTHENTICATION MIDDLEWARE
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];

    const token =
        authHeader &&
        authHeader.split(" ")[1];


    if (!token) {

        return res.status(401).json({
            message: "Please login first"
        });

    }


    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({
                    message:
                        "Invalid or expired token"
                });

            }


            req.user = user;

            next();

        }
    );

}


// ======================================
// CREATE BOOKING
// ======================================

router.post(
    "/",
    authenticateToken,
    (req, res) => {

        const userId =
            req.user.id;


        const {
            event_id,
            quantity
        } = req.body;


        // ======================================
        // CHECK INPUT
        // ======================================

        if (!event_id || !quantity) {

            return res.status(400).json({
                message:
                    "Event ID and quantity are required"
            });

        }


        if (
            !Number.isInteger(quantity) ||
            quantity <= 0
        ) {

            return res.status(400).json({
                message:
                    "Quantity must be a positive number"
            });

        }


        // ======================================
        // START TRANSACTION
        // ======================================

        db.beginTransaction(
            (transactionError) => {

                if (transactionError) {

                    console.error(
                        "TRANSACTION START ERROR:",
                        transactionError
                    );

                    return res.status(500).json({
                        message:
                            "Failed to start booking transaction"
                    });

                }


                // ======================================
                // GET EVENT
                // ======================================

                const eventSql = `
                    SELECT
                        id,
                        title,
                        ticket_price,
                        available_seats
                    FROM events
                    WHERE id = ?
                    AND status = 'active'
                    FOR UPDATE
                `;


                db.query(
                    eventSql,
                    [event_id],
                    (err, events) => {

                        if (err) {

                            console.error(
                                "EVENT QUERY ERROR:",
                                err
                            );

                            return db.rollback(() => {

                                res.status(500).json({
                                    message:
                                        "Database error"
                                });

                            });

                        }


                        // ======================================
                        // EVENT NOT FOUND
                        // ======================================

                        if (
                            events.length === 0
                        ) {

                            return db.rollback(() => {

                                res.status(404).json({
                                    message:
                                        "Event not found"
                                });

                            });

                        }


                        const event =
                            events[0];


                        // ======================================
                        // CHECK AVAILABLE SEATS
                        // ======================================

                        if (
                            Number(
                                event.available_seats
                            ) < quantity
                        ) {

                            return db.rollback(() => {

                                res.status(400).json({
                                    message:
                                        "Not enough seats available"
                                });

                            });

                        }


                        // ======================================
                        // CALCULATE TOTAL
                        // ======================================

                        const totalAmount =
                            Number(
                                event.ticket_price
                            ) * quantity;


                        // ======================================
                        // CREATE PENDING BOOKING
                        // ======================================

                        const bookingSql = `
                            INSERT INTO bookings
                            (
                                user_id,
                                event_id,
                                quantity,
                                total_amount,
                                booking_status
                            )
                            VALUES (?, ?, ?, ?, 'pending')
                        `;


                        db.query(
                            bookingSql,
                            [
                                userId,
                                event_id,
                                quantity,
                                totalAmount
                            ],
                            (err, result) => {

                                if (err) {

                                    console.error(
                                        "BOOKING INSERT ERROR:",
                                        err
                                    );

                                    return db.rollback(() => {

                                        res.status(500).json({
                                            message:
                                                "Failed to create booking"
                                        });

                                    });

                                }


                                const bookingId =
                                    result.insertId;


                                // ======================================
                                // REDUCE AVAILABLE SEATS
                                // ======================================

                                const updateSeatsSql = `
                                    UPDATE events
                                    SET available_seats =
                                        available_seats - ?
                                    WHERE id = ?
                                    AND available_seats >= ?
                                `;


                                db.query(
                                    updateSeatsSql,
                                    [
                                        quantity,
                                        event_id,
                                        quantity
                                    ],
                                    (err, seatResult) => {

                                        if (err) {

                                            console.error(
                                                "SEAT UPDATE ERROR:",
                                                err
                                            );

                                            return db.rollback(() => {

                                                res.status(500).json({
                                                    message:
                                                        "Failed to update available seats"
                                                });

                                            });

                                        }


                                        // ======================================
                                        // DOUBLE CHECK SEAT UPDATE
                                        // ======================================

                                        if (
                                            seatResult.affectedRows === 0
                                        ) {

                                            return db.rollback(() => {

                                                res.status(400).json({
                                                    message:
                                                        "Not enough seats available"
                                                });

                                            });

                                        }


                                        // ======================================
                                        // COMMIT TRANSACTION
                                        // ======================================

                                        db.commit(
                                            (commitError) => {

                                                if (commitError) {

                                                    console.error(
                                                        "COMMIT ERROR:",
                                                        commitError
                                                    );

                                                    return db.rollback(
                                                        () => {

                                                            res.status(500).json({
                                                                message:
                                                                    "Failed to complete booking"
                                                            });

                                                        }
                                                    );

                                                }


                                                // ======================================
                                                // BOOKING SUCCESS
                                                // ======================================

                                                res.status(201).json({

                                                    message:
                                                        "Booking created. Please complete payment.",

                                                    bookingId:
                                                        bookingId,

                                                    event:
                                                        event.title,

                                                    quantity:
                                                        quantity,

                                                    totalAmount:
                                                        totalAmount,

                                                    bookingStatus:
                                                        "pending"

                                                });

                                            }
                                        );

                                    }
                                );

                            }
                        );

                    }
                );

            }
        );

    }
);


// ======================================
// GET USER BOOKINGS
// ======================================

router.get(
    "/my-bookings",
    authenticateToken,
    (req, res) => {

        const userId =
            req.user.id;


        const sql = `
            SELECT
                bookings.id,
                bookings.quantity,
                bookings.total_amount,
                bookings.booking_status,
                bookings.booking_date,

                events.title,
                events.event_date,
                events.event_time,
                events.venue,

                tickets.ticket_code

            FROM bookings

            INNER JOIN events
                ON bookings.event_id = events.id

            LEFT JOIN tickets
                ON bookings.id = tickets.booking_id

            WHERE bookings.user_id = ?

            ORDER BY bookings.booking_date DESC
        `;


        db.query(
            sql,
            [userId],
            (err, results) => {

                if (err) {

                    console.error(
                        "MY BOOKINGS ERROR:",
                        err
                    );

                    return res.status(500).json({
                        message:
                            "Failed to fetch bookings"
                    });

                }


                console.log(
                    "MY BOOKINGS RESULT:",
                    results
                );


                res.json(results);

            }
        );

    }
);


// ======================================
// EXPORT ROUTER
// ======================================

module.exports = router;

