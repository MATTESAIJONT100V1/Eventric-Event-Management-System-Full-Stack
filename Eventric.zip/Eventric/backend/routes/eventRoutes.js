const express = require("express");

const router = express.Router();

const db = require("../db");

const authenticateToken =
    require("../middleware/authMiddleware");


// ======================================
// ORGANIZER / ADMIN AUTH CHECK
// ======================================

function checkOrganizer(req, res, next) {

    if (!req.user) {

        return res.status(401).json({
            message: "Authentication required"
        });

    }

    const role =
        String(req.user.role || "")
            .trim()
            .toLowerCase();

    if (
        role !== "organizer" &&
        role !== "admin"
    ) {

        return res.status(403).json({
            message: "Organizer access required"
        });

    }

    next();

}


// ======================================
// GET ALL ACTIVE EVENTS
// PUBLIC
// ======================================

router.get("/", (req, res) => {

    const sql = `
        SELECT
            id,
            organizer_id,
            title,
            description,
            category,
            event_date,
            event_time,
            venue,
            ticket_price,
            total_seats,
            available_seats,
            image,
            status
        FROM events
        WHERE status = 'active'
        ORDER BY event_date ASC, event_time ASC
    `;


    db.query(
        sql,
        (err, results) => {

            if (err) {

                console.error(
                    "GET EVENTS ERROR:",
                    err
                );

                return res.status(500).json({
                    message: "Failed to load events",
                    error: err.message,
                    code: err.code
                });

            }

            res.json(results);

        }
    );

});


// ======================================
// CREATE EVENT
// ORGANIZER / ADMIN
// ======================================

router.post(
    "/create",
    authenticateToken,
    checkOrganizer,
    (req, res) => {

        const {
            title,
            description,
            category,
            date,
            time,
            location,
            price,
            total_seats,
            image
        } = req.body;


        // ======================================
        // VALIDATION
        // ======================================

        if (
            !title ||
            !category ||
            !date ||
            !time ||
            !location ||
            price === undefined ||
            total_seats === undefined
        ) {

            return res.status(400).json({
                message:
                    "Please provide all required event information"
            });

        }


        // ======================================
        // VALIDATE PRICE
        // ======================================

        if (
            Number.isNaN(Number(price)) ||
            Number(price) < 0
        ) {

            return res.status(400).json({
                message:
                    "Ticket price cannot be negative"
            });

        }


        // ======================================
        // VALIDATE SEATS
        // ======================================

        if (
            !Number.isInteger(Number(total_seats)) ||
            Number(total_seats) <= 0
        ) {

            return res.status(400).json({
                message:
                    "Total seats must be a positive number"
            });

        }


        // ======================================
        // INSERT EVENT
        // ======================================

        const sql = `
            INSERT INTO events
            (
                organizer_id,
                title,
                description,
                category,
                event_date,
                event_time,
                venue,
                ticket_price,
                total_seats,
                available_seats,
                image,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')
        `;


        const values = [

            req.user.id,

            title,

            description || "",

            category,

            date,

            time,

            location,

            Number(price),

            Number(total_seats),

            Number(total_seats),

            image || ""

        ];


        db.query(
            sql,
            values,
            (err, result) => {

                if (err) {

                    console.error(
                        "CREATE EVENT ERROR:",
                        err
                    );

                    return res.status(500).json({
                        message:
                            "Failed to create event",
                        error:
                            err.message,
                        code:
                            err.code
                    });

                }


                res.status(201).json({

                    message:
                        "Event created successfully",

                    eventId:
                        result.insertId

                });

            }
        );

    }
);


// ======================================
// GET ORGANIZER'S EVENTS
// ORGANIZER / ADMIN
// ======================================

router.get(
    "/organizer/my-events",
    authenticateToken,
    checkOrganizer,
    (req, res) => {

        const sql = `
            SELECT
                id,
                organizer_id,
                title,
                description,
                category,
                event_date,
                event_time,
                venue,
                ticket_price,
                total_seats,
                available_seats,
                image,
                status
            FROM events
            WHERE organizer_id = ?
            ORDER BY event_date DESC, event_time DESC
        `;


        db.query(
            sql,
            [req.user.id],
            (err, results) => {

                if (err) {

                    console.error(
                        "ORGANIZER EVENTS ERROR:",
                        err
                    );

                    return res.status(500).json({
                        message:
                            "Failed to load organizer events",
                        error:
                            err.message,
                        code:
                            err.code
                    });

                }

                res.json(results);

            }
        );

    }
);


// ======================================
// GET SINGLE EVENT
// PUBLIC
// ======================================

router.get("/:id", (req, res) => {

    const eventId =
        req.params.id;


    const sql = `
        SELECT
            id,
            organizer_id,
            title,
            description,
            category,
            event_date,
            event_time,
            venue,
            ticket_price,
            total_seats,
            available_seats,
            image,
            status
        FROM events
        WHERE id = ?
    `;


    db.query(
        sql,
        [eventId],
        (err, results) => {

            if (err) {

                console.error(
                    "GET SINGLE EVENT ERROR:",
                    err
                );

                return res.status(500).json({
                    message:
                        "Failed to load event",
                    error:
                        err.message,
                    code:
                        err.code
                });

            }


            if (results.length === 0) {

                return res.status(404).json({
                    message:
                        "Event not found"
                });

            }


            res.json(results[0]);

        }
    );

});


// ======================================
// UPDATE EVENT
// ADMIN = ALL EVENTS
// ORGANIZER = OWN EVENTS
// ======================================

router.put(
    "/:id",
    authenticateToken,
    checkOrganizer,
    (req, res) => {

        const eventId =
            req.params.id;


        const {
            title,
            description,
            category,

            // Frontend-friendly names
            date,
            time,
            location,
            price,

            total_seats,

            // Optional
            image,
            status
        } = req.body;


        const role =
            String(req.user.role || "")
                .trim()
                .toLowerCase();


        const isAdmin =
            role === "admin";


        // ======================================
        // VALIDATE REQUIRED INFORMATION
        // ======================================

        if (
            !title ||
            !category ||
            !date ||
            !time ||
            !location ||
            price === undefined ||
            price === null ||
            total_seats === undefined ||
            total_seats === null
        ) {

            return res.status(400).json({

                message:
                    "Please provide all required event information"

            });

        }


        // ======================================
        // VALIDATE PRICE
        // ======================================

        if (
            Number.isNaN(Number(price)) ||
            Number(price) < 0
        ) {

            return res.status(400).json({

                message:
                    "Ticket price cannot be negative"

            });

        }


        // ======================================
        // VALIDATE TOTAL SEATS
        // ======================================

        if (
            !Number.isInteger(Number(total_seats)) ||
            Number(total_seats) <= 0
        ) {

            return res.status(400).json({

                message:
                    "Total seats must be a positive number"

            });

        }


        // ======================================
        // FIND EXISTING EVENT
        // ======================================

        const findSql = `
            SELECT
                id,
                organizer_id,
                total_seats,
                available_seats,
                image,
                status
            FROM events
            WHERE id = ?
        `;


        db.query(
            findSql,
            [eventId],
            (findErr, results) => {

                if (findErr) {

                    console.error(
                        "FIND EVENT FOR UPDATE ERROR:",
                        findErr
                    );

                    return res.status(500).json({

                        message:
                            "Database error",

                        error:
                            findErr.message,

                        code:
                            findErr.code

                    });

                }


                // ======================================
                // EVENT NOT FOUND
                // ======================================

                if (results.length === 0) {

                    return res.status(404).json({

                        message:
                            "Event not found"

                    });

                }


                const event =
                    results[0];


                // ======================================
                // ORGANIZER OWNERSHIP CHECK
                // ======================================

                if (
                    !isAdmin &&
                    Number(event.organizer_id) !==
                    Number(req.user.id)
                ) {

                    return res.status(403).json({

                        message:
                            "You can only manage your own events"

                    });

                }


                // ======================================
                // CALCULATE BOOKED SEATS
                // ======================================

                const currentTotalSeats =
                    Number(event.total_seats);


                const currentAvailableSeats =
                    Number(event.available_seats);


                const bookedSeats =
                    currentTotalSeats -
                    currentAvailableSeats;


                const newTotalSeats =
                    Number(total_seats);


                // ======================================
                // PREVENT SEAT REDUCTION
                // ======================================

                if (
                    newTotalSeats <
                    bookedSeats
                ) {

                    return res.status(400).json({

                        message:
                            `Cannot set total seats to ${newTotalSeats}. ` +
                            `${bookedSeats} seat(s) are already booked.`

                    });

                }


                // ======================================
                // CALCULATE NEW AVAILABLE SEATS
                // ======================================

                const newAvailableSeats =
                    newTotalSeats -
                    bookedSeats;


                // ======================================
                // KEEP OLD IMAGE IF NEW ONE IS EMPTY
                // ======================================

                const finalImage =
                    image !== undefined &&
                    String(image).trim() !== ""
                        ? String(image).trim()
                        : event.image || "";


                // ======================================
                // KEEP OLD STATUS IF NOT PROVIDED
                // ======================================

                const finalStatus =
                    status !== undefined &&
                    String(status).trim() !== ""
                        ? String(status).trim()
                        : event.status || "active";


                // ======================================
                // UPDATE EVENT
                // ======================================

                const updateSql = `
                    UPDATE events
                    SET
                        title = ?,
                        description = ?,
                        category = ?,
                        event_date = ?,
                        event_time = ?,
                        venue = ?,
                        ticket_price = ?,
                        total_seats = ?,
                        available_seats = ?,
                        image = ?,
                        status = ?
                    WHERE id = ?
                `;


                const values = [

                    title,

                    description || "",

                    category,

                    date,

                    time,

                    location,

                    Number(price),

                    newTotalSeats,

                    newAvailableSeats,

                    finalImage,

                    finalStatus,

                    eventId

                ];


                db.query(
                    updateSql,
                    values,
                    (updateErr, result) => {

                        if (updateErr) {

                            console.error(
                                "UPDATE EVENT ERROR:",
                                updateErr
                            );

                            return res.status(500).json({

                                message:
                                    "Failed to update event",

                                error:
                                    updateErr.message,

                                code:
                                    updateErr.code

                            });

                        }


                        if (
                            result.affectedRows === 0
                        ) {

                            return res.status(404).json({

                                message:
                                    "Event not found or access denied"

                            });

                        }


                        res.json({

                            message:
                                "Event updated successfully",

                            totalSeats:
                                newTotalSeats,

                            availableSeats:
                                newAvailableSeats,

                            bookedSeats:
                                bookedSeats

                        });

                    }
                );

            }
        );

    }
);


// ======================================
// CANCEL EVENT
// ADMIN = ANY EVENT
// ORGANIZER = OWN EVENT
// ======================================

router.put(
    "/:id/cancel",
    authenticateToken,
    checkOrganizer,
    (req, res) => {

        const eventId =
            req.params.id;


        const role =
            String(req.user.role || "")
                .trim()
                .toLowerCase();


        const isAdmin =
            role === "admin";


        const findSql = `
            SELECT
                id,
                status,
                organizer_id
            FROM events
            WHERE id = ?
        `;


        db.query(
            findSql,
            [eventId],
            (findErr, results) => {

                if (findErr) {

                    console.error(
                        "FIND EVENT ERROR:",
                        findErr
                    );

                    return res.status(500).json({

                        message:
                            "Database error",

                        error:
                            findErr.message,

                        code:
                            findErr.code

                    });

                }


                if (results.length === 0) {

                    return res.status(404).json({

                        message:
                            "Event not found"

                    });

                }


                const event =
                    results[0];


                if (
                    !isAdmin &&
                    Number(event.organizer_id) !==
                    Number(req.user.id)
                ) {

                    return res.status(403).json({

                        message:
                            "You can only manage your own events"

                    });

                }


                if (
                    String(event.status)
                        .trim()
                        .toLowerCase() ===
                    "cancelled"
                ) {

                    return res.json({

                        message:
                            "Event is already cancelled"

                    });

                }


                const updateSql = `
                    UPDATE events
                    SET status = 'cancelled'
                    WHERE id = ?
                `;


                db.query(
                    updateSql,
                    [eventId],
                    (updateErr) => {

                        if (updateErr) {

                            console.error(
                                "CANCEL EVENT ERROR:",
                                updateErr
                            );

                            return res.status(500).json({

                                message:
                                    "Failed to cancel event",

                                error:
                                    updateErr.message,

                                code:
                                    updateErr.code

                            });

                        }


                        res.json({

                            message:
                                "Event cancelled successfully"

                        });

                    }
                );

            }
        );

    }
);


// ======================================
// ACTIVATE EVENT
// ADMIN = ANY EVENT
// ORGANIZER = OWN EVENT
// ======================================

router.put(
    "/:id/activate",
    authenticateToken,
    checkOrganizer,
    (req, res) => {

        const eventId =
            req.params.id;


        const role =
            String(req.user.role || "")
                .trim()
                .toLowerCase();


        const isAdmin =
            role === "admin";


        const findSql = `
            SELECT
                id,
                status,
                organizer_id
            FROM events
            WHERE id = ?
        `;


        db.query(
            findSql,
            [eventId],
            (findErr, results) => {

                if (findErr) {

                    console.error(
                        "FIND EVENT ERROR:",
                        findErr
                    );

                    return res.status(500).json({

                        message:
                            "Database error",

                        error:
                            findErr.message,

                        code:
                            findErr.code

                    });

                }


                if (results.length === 0) {

                    return res.status(404).json({

                        message:
                            "Event not found"

                    });

                }


                const event =
                    results[0];


                if (
                    !isAdmin &&
                    Number(event.organizer_id) !==
                    Number(req.user.id)
                ) {

                    return res.status(403).json({

                        message:
                            "You can only manage your own events"

                    });

                }


                if (
                    String(event.status)
                        .trim()
                        .toLowerCase() ===
                    "active"
                ) {

                    return res.json({

                        message:
                            "Event is already active"

                    });

                }


                const updateSql = `
                    UPDATE events
                    SET status = 'active'
                    WHERE id = ?
                `;


                db.query(
                    updateSql,
                    [eventId],
                    (updateErr) => {

                        if (updateErr) {

                            console.error(
                                "ACTIVATE EVENT ERROR:",
                                updateErr
                            );

                            return res.status(500).json({

                                message:
                                    "Failed to activate event",

                                error:
                                    updateErr.message,

                                code:
                                    updateErr.code

                            });

                        }


                        res.json({

                            message:
                                "Event activated successfully"

                        });

                    }
                );

            }
        );

    }
);


// ======================================
// DELETE EVENT
// ADMIN / ORGANIZER
// ======================================

router.delete(
    "/:id",
    authenticateToken,
    checkOrganizer,
    async (req, res) => {

        try {

            const eventId =
                req.params.id;


            // ======================================
            // CHECK EVENT
            // ======================================

            const [events] =
                await db.promise().query(
                    `
                    SELECT
                        id,
                        title,
                        organizer_id
                    FROM events
                    WHERE id = ?
                    `,
                    [eventId]
                );


            if (events.length === 0) {

                return res.status(404).json({

                    message:
                        "Event not found."

                });

            }


            const event =
                events[0];


            const role =
                String(req.user.role || "")
                    .trim()
                    .toLowerCase();


            // ======================================
            // ORGANIZER OWNERSHIP
            // ======================================

            if (
                role !== "admin" &&
                Number(event.organizer_id) !==
                Number(req.user.id)
            ) {

                return res.status(403).json({

                    message:
                        "You can only manage your own events"

                });

            }


            // ======================================
            // CHECK BOOKINGS
            // ======================================

            const [bookings] =
                await db.promise().query(
                    `
                    SELECT COUNT(*) AS total
                    FROM bookings
                    WHERE event_id = ?
                    `,
                    [eventId]
                );


            if (
                bookings[0].total > 0
            ) {

                return res.status(400).json({

                    message:
                        "This event cannot be deleted because it has existing bookings."

                });

            }


            // ======================================
            // DELETE EVENT
            // ======================================

            await db.promise().query(
                `
                DELETE FROM events
                WHERE id = ?
                `,
                [eventId]
            );


            // ======================================
            // SUCCESS
            // ======================================

            res.json({

                message:
                    "Event deleted successfully."

            });


        } catch (error) {

            console.error(
                "DELETE EVENT ERROR:",
                error
            );


            res.status(500).json({

                message:
                    "Failed to delete event."

            });

        }

    }
);


module.exports = router;