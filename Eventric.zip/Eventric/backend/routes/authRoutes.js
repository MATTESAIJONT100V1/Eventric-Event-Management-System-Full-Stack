const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const router = express.Router();
const db = require("../db");


// ======================================
// REGISTER
// ======================================

router.post("/register", async (req, res) => {

    const { name, email, password } = req.body;

    if (!name || !email || !password) {

        return res.status(400).json({
            message: "Name, email and password are required"
        });

    }

    try {

        // Check if email already exists
        const checkSql = `
            SELECT id
            FROM users
            WHERE email = ?
        `;

        db.query(
            checkSql,
            [email],
            async (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message: "Database error"
                    });

                }

                if (results.length > 0) {

                    return res.status(400).json({
                        message: "Email already registered"
                    });

                }

                // Hash password
                const hashedPassword =
                    await bcrypt.hash(password, 10);

                // Create normal user
                const insertSql = `
                    INSERT INTO users
                    (name, email, password, role)
                    VALUES (?, ?, ?, 'user')
                `;

                db.query(
                    insertSql,
                    [
                        name,
                        email,
                        hashedPassword
                    ],
                    (insertErr, result) => {

                        if (insertErr) {

                            console.error(insertErr);

                            return res.status(500).json({
                                message: "Registration failed"
                            });

                        }

                        res.status(201).json({

                            message:
                                "Registration successful",

                            userId:
                                result.insertId

                        });

                    }
                );

            }
        );

    } catch (error) {

        console.error(error);

        res.status(500).json({
            message: "Server error"
        });

    }

});


// ======================================
// LOGIN
// ======================================

router.post("/login", (req, res) => {

    const { email, password } = req.body;


    // Check input
    if (!email || !password) {

        return res.status(400).json({
            message:
                "Email and password are required"
        });

    }


    // Find user
    const sql = `
        SELECT
            id,
            name,
            email,
            password,
            role
        FROM users
        WHERE email = ?
    `;


    db.query(
        sql,
        [email],
        async (err, results) => {

            if (err) {

                console.error(err);

                return res.status(500).json({
                    message:
                        "Database error"
                });

            }


            // User not found
            if (results.length === 0) {

                return res.status(401).json({
                    message:
                        "Invalid email or password"
                });

            }


            const user = results[0];


            // Check password
            const passwordMatch =
                await bcrypt.compare(
                    password,
                    user.password
                );


            if (!passwordMatch) {

                return res.status(401).json({
                    message:
                        "Invalid email or password"
                });

            }


            // ======================================
            // NORMALIZE USER ROLE
            // ======================================

            const userRole =
                String(user.role || "")
                    .trim()
                    .toLowerCase();


            // ======================================
            // CREATE JWT
            // ======================================

            const token =
                jwt.sign(
                    {
                        id: user.id,
                        email: user.email,
                        role: userRole
                    },

                    "eventric_secret_key",

                    {
                        expiresIn: "1d"
                    }
                );


            // ======================================
            // SEND RESPONSE
            // ======================================

            res.json({

                message:
                    "Login successful",

                token: token,

                user: {

                    id: user.id,

                    name: user.name,

                    email: user.email,

                    role: userRole

                }

            });

        }
    );

});


module.exports = router;