const express = require("express");
const router = express.Router();

const db = require("../db");
const jwt = require("jsonwebtoken");


// ======================================
// AUTHENTICATION MIDDLEWARE
// ======================================

function authenticateToken(req, res, next) {

    const authHeader =
        req.headers["authorization"];

    const token =
        authHeader && authHeader.split(" ")[1];

    if (!token) {

        return res.status(401).json({
            message: "Please login first"
        });

    }

    jwt.verify(
        token,
        "eventric_secret_key",
        (err, user) => {

            if (err) {

                return res.status(403).json({
                    message:
                        "Invalid or expired token"
                });

            }

            req.user = user;

            next();

        }
    );

}


// ======================================
// TEST PAYMENT ROUTE
// ======================================

router.get("/test", (req, res) => {

    res.json({
        message:
            "Payment route is working!"
    });

});


// ======================================
// CREATE PAYMENT
// ======================================

router.post(
    "/",
    authenticateToken,
    (req, res) => {

        const userId =
            req.user.id;

        const {
            booking_id,
            payment_method
        } = req.body;


        // ======================================
        // CHECK INPUT
        // ======================================

        if (
            !booking_id ||
            !payment_method
        ) {

            return res.status(400).json({
                message:
                    "Booking ID and payment method are required"
            });

        }


        // ======================================
        // GET BOOKING
        // ======================================

        const bookingSql = `
            SELECT
                bookings.id,
                bookings.user_id,
                bookings.event_id,
                bookings.quantity,
                bookings.total_amount,
                bookings.booking_status
            FROM bookings
            WHERE bookings.id = ?
        `;


        db.query(
            bookingSql,
            [booking_id],
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Database error"
                    });

                }


                // ======================================
                // BOOKING NOT FOUND
                // ======================================

                if (
                    results.length === 0
                ) {

                    return res.status(404).json({
                        message:
                            "Booking not found"
                    });

                }


                const booking =
                    results[0];


                // ======================================
                // CHECK BOOKING OWNER
                // ======================================

                if (
                    booking.user_id !== userId
                ) {

                    return res.status(403).json({
                        message:
                            "You are not allowed to pay for this booking"
                    });

                }


                // ======================================
                // CHECK BOOKING STATUS
                // ======================================

                if (
                    booking.booking_status ===
                    "confirmed"
                ) {

                    return res.status(400).json({
                        message:
                            "This booking is already confirmed"
                    });

                }


                // ======================================
                // CHECK EXISTING PAYMENT
                // ======================================

                const paymentCheckSql = `
                    SELECT
                        id,
                        payment_status
                    FROM payments
                    WHERE booking_id = ?
                    AND payment_status = 'successful'
                `;


                db.query(
                    paymentCheckSql,
                    [booking_id],
                    (err, payments) => {

                        if (err) {

                            console.error(err);

                            return res.status(500).json({
                                message:
                                    "Failed to check payment"
                            });

                        }


                        // ======================================
                        // ALREADY PAID
                        // ======================================

                        if (
                            payments.length > 0
                        ) {

                            return res.status(400).json({
                                message:
                                    "Payment has already been completed"
                            });

                        }


                        // ======================================
                        // GENERATE TRANSACTION ID
                        // ======================================

                        const transactionId =
                            "TXN-" +
                            Date.now();


                        // ======================================
                        // SAVE PAYMENT
                        // ======================================

                        const paymentSql = `
                            INSERT INTO payments
                            (
                                booking_id,
                                amount,
                                payment_method,
                                transaction_id,
                                payment_status
                            )
                            VALUES (?, ?, ?, ?, 'successful')
                        `;


                        db.query(
                            paymentSql,
                            [
                                booking_id,
                                booking.total_amount,
                                payment_method,
                                transactionId
                            ],
                            (err, paymentResult) => {

                                if (err) {

                                    console.error(err);

                                    return res.status(500).json({
                                        message:
                                            "Payment failed"
                                    });

                                }


                                // ======================================
                                // CONFIRM BOOKING
                                // ======================================

                                const updateBookingSql = `
                                    UPDATE bookings
                                    SET booking_status = 'confirmed'
                                    WHERE id = ?
                                `;


                                db.query(
                                    updateBookingSql,
                                    [booking_id],
                                    (err) => {

                                        if (err) {

                                            console.error(err);

                                            return res.status(500).json({
                                                message:
                                                    "Payment saved but booking confirmation failed"
                                            });

                                        }


                                        // ======================================
                                        // GENERATE TICKET CODE
                                        // ======================================

                                        const ticketCode =
                                            "EVT-" +
                                            Date.now() +
                                            "-" +
                                            booking_id;


                                        // ======================================
                                        // CREATE TICKET
                                        // ======================================

                                        const ticketSql = `
                                            INSERT INTO tickets
                                            (
                                                booking_id,
                                                ticket_code
                                            )
                                            VALUES (?, ?)
                                        `;


                                        db.query(
                                            ticketSql,
                                            [
                                                booking_id,
                                                ticketCode
                                            ],
                                            (err) => {

                                                if (err) {

                                                    console.error(err);

                                                    return res.status(500).json({
                                                        message:
                                                            "Payment successful but ticket creation failed"
                                                    });

                                                }


                                                // ======================================
                                                // SUCCESS RESPONSE
                                                // ======================================

                                                res.status(201).json({

                                                    message:
                                                        "Payment successful and booking confirmed",

                                                    paymentId:
                                                        paymentResult.insertId,

                                                    bookingId:
                                                        booking_id,

                                                    amount:
                                                        booking.total_amount,

                                                    paymentMethod:
                                                        payment_method,

                                                    transactionId:
                                                        transactionId,

                                                    paymentStatus:
                                                        "successful",

                                                    bookingStatus:
                                                        "confirmed",

                                                    ticketCode:
                                                        ticketCode

                                                });

                                            }
                                        );

                                    }
                                );

                            }
                        );

                    }
                );

            }
        );

    }
);


// ======================================
// GET USER PAYMENTS
// ======================================

router.get(
    "/my-payments",
    authenticateToken,
    (req, res) => {

        const userId =
            req.user.id;


        const sql = `
            SELECT
                payments.id,
                payments.booking_id,
                payments.amount,
                payments.payment_method,
                payments.transaction_id,
                payments.payment_status,
                payments.payment_date

            FROM payments

            INNER JOIN bookings
                ON payments.booking_id =
                   bookings.id

            WHERE bookings.user_id = ?

            ORDER BY payments.payment_date DESC
        `;


        db.query(
            sql,
            [userId],
            (err, results) => {

                if (err) {

                    console.error(err);

                    return res.status(500).json({
                        message:
                            "Failed to fetch payments"
                    });

                }


                res.json(results);

            }
        );

    }
);


// ======================================
// EXPORT ROUTER
// ======================================

module.exports = router;