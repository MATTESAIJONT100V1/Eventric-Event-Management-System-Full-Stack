
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

const app = express();

dotenv.config();


// ======================================
// CONNECT TO MYSQL
// ======================================

require("./db");


// ======================================
// AUTOMATIC BOOKING EXPIRATION
// ======================================

require("./bookingExpiry");


// ======================================
// MIDDLEWARE
// ======================================

app.use(cors());
app.use(express.json());


// ======================================
// EVENT ROUTES
// ======================================

const eventRoutes =
    require("./routes/eventRoutes");

app.use(
    "/api/events",
    eventRoutes
);


// ======================================
// AUTH ROUTES
// ======================================

const authRoutes =
    require("./routes/authRoutes");

app.use(
    "/api/auth",
    authRoutes
);


// ======================================
// BOOKING ROUTES
// ======================================

const bookingRoutes =
    require("./routes/bookingRoutes");

app.use(
    "/api/bookings",
    bookingRoutes
);


// ======================================
// PAYMENT ROUTES
// ======================================

const paymentRoutes =
    require("./routes/paymentRoutes");

app.use(
    "/api/payments",
    paymentRoutes
);


// ======================================
// TICKET ROUTES
// ======================================

const ticketRoutes =
    require("./routes/ticketRoutes");

app.use(
    "/api/tickets",
    ticketRoutes
);


// ======================================
// ADMIN ROUTES
// ======================================

const adminRoutes =
    require("./routes/adminRoutes");

app.use(
    "/api/admin",
    adminRoutes
);


// ======================================
// TEST ROUTE
// ======================================

app.get("/", (req, res) => {

    res.send(
        "Eventric API is running!"
    );

});


// ======================================
// START SERVER
// ======================================

const PORT = 3000;

app.listen(PORT, () => {

    console.log(
        `Eventric server running on http://localhost:${PORT}`
    );

});

