function searchEvents() {

    const searchText =
        document.getElementById("searchInput").value
        .toLowerCase();

    const category =
        document.getElementById("categoryFilter").value;

    const cards =
        document.querySelectorAll(".event-card");

    cards.forEach(card => {

        const title =
            card.querySelector("h3")
            .textContent
            .toLowerCase();

        const eventCategory =
            card.querySelector(".event-image span")
            .textContent
            .toLowerCase();

        const matchesSearch =
            title.includes(searchText);

        const matchesCategory =
            category === "all" ||
            eventCategory === category;

        if (matchesSearch && matchesCategory) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }

    });
}