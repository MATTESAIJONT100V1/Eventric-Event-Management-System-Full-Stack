
// ======================================
// GET LOGIN INFORMATION
// ======================================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user")
    );


// ======================================
// CHECK LOGIN
// ======================================

if (!token || !user) {

    alert("Please login first.");

    window.location.href =
        "login.html";

}


// ======================================
// CHECK USER ROLE
// ======================================

const userRole =
    String(user.role || "")
        .trim()
        .toLowerCase();


// ======================================
// ACCESS CHECK
// ======================================

if (
    userRole !== "organizer" &&
    userRole !== "admin"
) {

    document.getElementById(
        "result"
    ).innerHTML = `

        <div class="error-message">

            <h2>
                🚫 Access Denied
            </h2>

            <p>
                Only an Organizer or Admin
                can verify tickets.
            </p>

        </div>

    `;

}


// ======================================
// VERIFY TICKET
// ======================================

async function verifyTicket() {

    const ticketInput =
        document.getElementById(
            "ticketCode"
        );

    const result =
        document.getElementById(
            "result"
        );


    // ======================================
    // GET TICKET CODE
    // ======================================

    const ticketCode =
        ticketInput.value.trim();


    if (!ticketCode) {

        result.innerHTML = `

            <div class="error-message">

                <h3>
                    ⚠️ Please enter a ticket code.
                </h3>

            </div>

        `;

        return;

    }


    // ======================================
    // LOADING
    // ======================================

    result.innerHTML = `

        <p>
            🔄 Verifying ticket...
        </p>

    `;


    try {

        // ======================================
        // SEND REQUEST
        // ======================================

        const response =
            await fetch(

                `http://localhost:3000/api/tickets/verify/${encodeURIComponent(ticketCode)}`,

                {

                    method: "GET",

                    headers: {

                        "Authorization":
                            `Bearer ${token}`

                    }

                }

            );


        const data =
            await response.json();


        console.log(
            "VERIFY RESPONSE:",
            data
        );


        // ======================================
        // INVALID TICKET
        // ======================================

        if (!response.ok) {

            result.innerHTML = `

                <div class="error-message">

                    <h2>
                        ❌ Invalid Ticket
                    </h2>

                    <p>
                        ${
                            data.message ||
                            "This ticket is invalid."
                        }
                    </p>

                </div>

            `;

            return;

        }


        // ======================================
        // VALID TICKET
        // ======================================

        result.innerHTML = `

            <div class="success-message">

                <h2>
                    ✅ Valid Ticket
                </h2>

                <p>
                    <strong>
                        Ticket Code:
                    </strong>
                    ${data.ticket_code}
                </p>

                <p>
                    <strong>
                        Event:
                    </strong>
                    ${data.title}
                </p>

                <p>
                    <strong>
                        Category:
                    </strong>
                    ${data.category || "N/A"}
                </p>

                <p>
                    <strong>
                        Date:
                    </strong>
                    ${formatDate(data.event_date)}
                </p>

                <p>
                    <strong>
                        Time:
                    </strong>
                    ${formatTime(data.event_time)}
                </p>

                <p>
                    <strong>
                        Venue:
                    </strong>
                    ${data.venue || "N/A"}
                </p>

                <p>
                    <strong>
                        Tickets:
                    </strong>
                    ${data.quantity}
                </p>

                <p>
                    <strong>
                        Booking Status:
                    </strong>
                    ${data.booking_status}
                </p>

                <p>
                    <strong>
                        Payment:
                    </strong>
                    ${data.payment_status}
                </p>

            </div>

        `;


    } catch (error) {

        console.error(
            "VERIFY ERROR:",
            error
        );


        result.innerHTML = `

            <div class="error-message">

                <h2>
                    ❌ Verification Failed
                </h2>

                <p>
                    ${error.message}
                </p>

            </div>

        `;

    }

}


// ======================================
// FORMAT DATE
// ======================================

function formatDate(date) {

    if (!date) {

        return "N/A";

    }


    const d =
        new Date(date);


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ======================================
// FORMAT TIME
// ======================================

function formatTime(time) {

    if (!time) {

        return "N/A";

    }


    const parts =
        time.split(":");


    let hour =
        parseInt(parts[0]);


    const minute =
        parts[1];


    const ampm =
        hour >= 12
            ? "PM"
            : "AM";


    hour =
        hour % 12 || 12;


    return `${hour}:${minute} ${ampm}`;

}


// ======================================
// QR CODE AUTO VERIFICATION
// ======================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );


const qrCode =
    urlParams.get("code");


if (qrCode) {

    document.getElementById(
        "ticketCode"
    ).value =
        qrCode;

    verifyTicket();

}

