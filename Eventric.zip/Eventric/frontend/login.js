const loginForm =
    document.getElementById("loginForm");

const loginMessage =
    document.getElementById("loginMessage");


loginForm.addEventListener(
    "submit",
    async function (event) {

        event.preventDefault();


        const email =
            document.getElementById("email").value;

        const password =
            document.getElementById("password").value;


        try {

            const response = await fetch(
                "http://localhost:3000/api/auth/login",
                {
                    method: "POST",

                    headers: {
                        "Content-Type": "application/json"
                    },

                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                }
            );


            const data =
                await response.json();


            if (!response.ok) {

                loginMessage.textContent =
                    data.message;

                return;
            }


            // ===============================
            // SAVE JWT TOKEN
            // ===============================

            localStorage.setItem(
                "token",
                data.token
            );


            // ===============================
            // SAVE USER INFORMATION
            // ===============================

            localStorage.setItem(
                "user",
                JSON.stringify(data.user)
            );


            loginMessage.textContent =
                "Login successful!";


            // ===============================
            // ROLE BASED REDIRECT
            // ===============================

            setTimeout(() => {

                if (data.user.role === "organizer") {

                    window.location.href =
                        "organizer-dashboard.html";

                } else if (data.user.role === "admin") {

                    window.location.href =
                        "admin-dashboard.html";

                } else {

                    window.location.href =
                        "dashboard.html";

                }

            }, 1000);


        } catch (error) {

            console.error(error);

            loginMessage.textContent =
                "Could not connect to server.";

        }

    }
);