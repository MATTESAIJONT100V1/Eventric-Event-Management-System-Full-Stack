
// ===============================
// GET LOGIN INFORMATION
// ===============================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user") || "null"
    );


// ===============================
// GLOBAL BOOKING ID
// ===============================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const bookingId =
    urlParams.get("booking_id");


// ===============================
// CHECK LOGIN
// ===============================

if (!token || !user) {

    alert(
        "Please login first."
    );

    window.location.href =
        "login.html";

} else {

    // ===============================
    // CHECK BOOKING ID
    // ===============================

    if (!bookingId) {

        const ticketContainer =
            document.getElementById(
                "ticketContainer"
            );

        if (ticketContainer) {

            ticketContainer.innerHTML = `

                <div class="error-message">

                    <h2>
                        Ticket Not Found
                    </h2>

                    <p>
                        Booking ID is missing.
                    </p>

                </div>

            `;

        }

    } else {

        loadTicket();

    }

}


// ===============================
// LOAD TICKET
// ===============================

async function loadTicket() {

    try {

        const response =
            await fetch(
                `http://localhost:3000/api/tickets/${bookingId}`,
                {
                    method: "GET",

                    headers: {

                        "Authorization":
                            `Bearer ${token}`

                    }

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load ticket"
            );

        }


        displayTicket(
            data
        );


    } catch (error) {

        console.error(error);


        const ticketContainer =
            document.getElementById(
                "ticketContainer"
            );


        if (ticketContainer) {

            ticketContainer.innerHTML = `

                <div class="error-message">

                    <h2>
                        Failed to Load Ticket
                    </h2>

                    <p>
                        ${error.message}
                    </p>

                </div>

            `;

        }

    }

}


// ===============================
// DISPLAY TICKET
// ===============================

function displayTicket(
    data
) {

    const ticketContainer =
        document.getElementById(
            "ticketContainer"
        );


    if (!ticketContainer) {

        console.error(
            "ticketContainer element not found."
        );

        return;

    }


    ticketContainer.innerHTML = `

        <h2>
            ${data.title || "Event"}
        </h2>


        <div class="ticket-info">

            <p>
                <strong>
                    📂 Category:
                </strong>

                ${data.category || "N/A"}
            </p>


            <p>
                <strong>
                    📅 Date:
                </strong>

                ${formatDate(
                    data.event_date
                )}
            </p>


            <p>
                <strong>
                    ⏰ Time:
                </strong>

                ${formatTime(
                    data.event_time
                )}
            </p>


            <p>
                <strong>
                    📍 Venue:
                </strong>

                ${data.venue || "N/A"}
            </p>


            <p>
                <strong>
                    🎟️ Number of Tickets:
                </strong>

                ${data.quantity ?? "N/A"}
            </p>


            <p>
                <strong>
                    💰 Total Amount:
                </strong>

                ৳${Number(
                    data.total_amount || 0
                ).toFixed(2)}
            </p>


            <p>
                <strong>
                    ✅ Booking Status:
                </strong>

                ${data.booking_status || "N/A"}
            </p>


            <p>
                <strong>
                    💳 Payment Method:
                </strong>

                ${data.payment_method || "N/A"}
            </p>


            <p>
                <strong>
                    💵 Payment Status:
                </strong>

                ${data.payment_status || "N/A"}
            </p>

        </div>


        <div class="transaction">

            <p>
                <strong>
                    Transaction ID:
                </strong>

                ${data.transaction_id || "N/A"}
            </p>

        </div>


        <div class="ticket-code">

            Ticket Code

            <strong id="ticketCode">

                ${data.ticket_code || "N/A"}

            </strong>

        </div>


        <div class="qr-section">

            <h3>
                📱 Scan QR Code
            </h3>

            <div id="qrcode"></div>

            <p>
                Show this QR code at the
                event entrance.
            </p>

        </div>

    `;


    // ======================================
    // GENERATE QR CODE
    // ======================================

    const qrContainer =
        document.getElementById(
            "qrcode"
        );


    if (!qrContainer) {

        console.error(
            "QR code container not found."
        );

        return;

    }


    if (!data.ticket_code) {

        qrContainer.innerHTML = `
            <p>
                QR code unavailable.
            </p>
        `;

        return;

    }


    qrContainer.innerHTML = "";


    // ======================================
    // CREATE VERIFICATION URL
    // ======================================

    const verificationURL =
        `${window.location.origin}/verify-ticket.html?code=${encodeURIComponent(data.ticket_code)}`;


    // ======================================
    // GENERATE QR CODE
    // ======================================

    if (typeof QRCode === "undefined") {

        qrContainer.innerHTML = `
            <p>
                ❌ QR Code library not loaded.
            </p>
        `;

        console.error(
            "QRCode library is not loaded."
        );

        return;

    }


    new QRCode(
        qrContainer,
        {
            text:
                verificationURL,

            width:
                180,

            height:
                180
        }
    );

}


// ===============================
// FORMAT DATE
// ===============================

function formatDate(
    dateString
) {

    if (!dateString) {

        return "N/A";

    }


    const date =
        new Date(dateString);


    if (isNaN(date.getTime())) {

        return "N/A";

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ===============================
// FORMAT TIME
// ===============================

function formatTime(
    timeString
) {

    if (!timeString) {

        return "N/A";

    }


    const parts =
        timeString.split(":");


    if (parts.length < 2) {

        return timeString;

    }


    let hours =
        parseInt(
            parts[0],
            10
        );


    const minutes =
        parts[1];


    if (isNaN(hours)) {

        return timeString;

    }


    const period =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {

        hours = 12;

    }


    return `${hours}:${minutes} ${period}`;

}
