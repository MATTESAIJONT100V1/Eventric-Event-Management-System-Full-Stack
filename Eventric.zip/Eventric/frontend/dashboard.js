
// ===============================
// GET LOGIN INFORMATION
// ===============================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user") || "null"
    );


// ===============================
// ESCAPE DYNAMIC TEXT
// ===============================

function escapeHTML(value) {

    if (value === null || value === undefined) {

        return "";

    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// ===============================
// CHECK LOGIN
// ===============================

if (!token || !user) {

    alert(
        "Please login first."
    );

    window.location.href =
        "login.html";

} else {

    // ===============================
    // DISPLAY USER
    // ===============================

    const userName =
        document.getElementById(
            "userName"
        );

    const userEmail =
        document.getElementById(
            "userEmail"
        );


    if (userName) {

        userName.textContent =
            user.name || "";

    }


    if (userEmail) {

        userEmail.textContent =
            user.email || "";

    }


    // ===============================
    // LOAD DATA
    // ===============================

    loadEvents();

    loadBookings();

}


// ===============================
// LOAD EVENTS
// ===============================

async function loadEvents() {

    const container =
        document.getElementById(
            "eventsContainer"
        );


    if (!container) {

        console.error(
            "eventsContainer not found."
        );

        return;

    }


    container.innerHTML = `

        <p>
            Loading events...
        </p>

    `;


    try {

        const response =
            await fetch(
                "http://localhost:3000/api/events",
                {
                    method: "GET",

                    headers: {

                        "Authorization":
                            `Bearer ${token}`,

                        "Content-Type":
                            "application/json"

                    }

                }
            );


        const events =
            await response.json();


        console.log(
            "Events response:",
            events
        );


        if (!response.ok) {

            throw new Error(
                events.message ||
                `Server error: ${response.status}`
            );

        }


        if (
            !Array.isArray(events) ||
            events.length === 0
        ) {

            container.innerHTML = `

                <div class="no-events">

                    <p>
                        No upcoming events available.
                    </p>

                </div>

            `;

            return;

        }


        // ===============================
        // DISPLAY EVENTS
        // ===============================

        container.innerHTML = `

            <div class="events-grid">

                ${
                    events.map(
                        event => `

                        <div class="event-card">

                            <h3>
                                ${escapeHTML(
                                    event.title ||
                                    "Untitled Event"
                                )}
                            </h3>


                            <span
                                class="event-category"
                            >

                                ${escapeHTML(
                                    event.category ||
                                    "General"
                                )}

                            </span>


                            <div
                                class="event-info"
                            >

                                <div>

                                    📅

                                    <strong>
                                        Date
                                    </strong>

                                    <br>

                                    ${escapeHTML(
                                        formatDate(
                                            event.event_date
                                        )
                                    )}

                                </div>


                                <div>

                                    ⏰

                                    <strong>
                                        Time
                                    </strong>

                                    <br>

                                    ${escapeHTML(
                                        formatTime(
                                            event.event_time
                                        )
                                    )}

                                </div>


                                <div>

                                    📍

                                    <strong>
                                        Venue
                                    </strong>

                                    <br>

                                    ${escapeHTML(
                                        event.venue ||
                                        "N/A"
                                    )}

                                </div>


                                <div>

                                    💰

                                    <strong>
                                        Price
                                    </strong>

                                    <br>

                                    ৳${Number(
                                        event.ticket_price || 0
                                    ).toFixed(2)}

                                </div>


                                <div>

                                    🎟️

                                    <strong>
                                        Available
                                    </strong>

                                    <br>

                                    ${escapeHTML(
                                        event.available_seats ?? 0
                                    )}

                                </div>

                            </div>


                            <button
                                class="view-details-btn"
                                data-event-id="${escapeHTML(
                                    event.id
                                )}"
                            >

                                View Details

                            </button>

                        </div>

                    `
                    ).join("")
                }

            </div>

        `;


        // ===============================
        // EVENT BUTTONS
        // ===============================

        const eventButtons =
            container.querySelectorAll(
                ".view-details-btn"
            );


        eventButtons.forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        const eventId =
                            button.dataset.eventId;

                        viewEvent(
                            eventId
                        );

                    }
                );

            }
        );


    } catch (error) {

        console.error(
            "Load events error:",
            error
        );


        container.innerHTML = `

            <div class="no-events">

                <h3>
                    ❌ Failed to load events
                </h3>

                <p>
                    ${escapeHTML(
                        error.message
                    )}
                </p>

            </div>

        `;

    }

}


// ===============================
// VIEW EVENT
// ===============================

function viewEvent(
    eventId
) {

    window.location.href =
        `event-details.html?id=${encodeURIComponent(
            eventId
        )}`;

}


// ===============================
// LOAD MY BOOKINGS
// ===============================

async function loadBookings() {

    const container =
        document.getElementById(
            "bookingContainer"
        );


    if (!container) {

        console.error(
            "bookingContainer not found."
        );

        return;

    }


    container.innerHTML = `

        <p>
            Loading bookings...
        </p>

    `;


    try {

        const response =
            await fetch(
                "http://localhost:3000/api/bookings/my-bookings",
                {
                    method: "GET",

                    headers: {

                        "Authorization":
                            `Bearer ${token}`,

                        "Content-Type":
                            "application/json"

                    }

                }
            );


        const bookings =
            await response.json();


        if (!response.ok) {

            throw new Error(
                bookings.message ||
                "Failed to load bookings"
            );

        }


        // ===============================
        // NO BOOKINGS
        // ===============================

        if (
            !Array.isArray(bookings) ||
            bookings.length === 0
        ) {

            container.innerHTML = `

                <div class="no-bookings">

                    <h3>
                        🎟️ No Bookings Yet
                    </h3>

                    <p>

                        You have not booked
                        any events yet.

                    </p>

                </div>

            `;

            return;

        }


        // ===============================
        // DISPLAY BOOKINGS
        // ===============================

        container.innerHTML =
            bookings.map(
                booking => {

                    const isConfirmed =
                        String(
                            booking.booking_status
                        )
                        .trim()
                        .toLowerCase() ===
                        "confirmed";


                    const isPending =
                        String(
                            booking.booking_status
                        )
                        .trim()
                        .toLowerCase() ===
                        "pending";


                    const statusClass =
                        isConfirmed
                            ? "confirmed"
                            : "pending";


                    return `

                        <div
                            class="booking-card"
                        >

                            <div
                                class="booking-header"
                            >

                                <h3>

                                    ${escapeHTML(
                                        booking.title ||
                                        "Untitled Event"
                                    )}

                                </h3>


                                <span
                                    class="
                                        booking-status
                                        ${statusClass}
                                    "
                                >

                                    ${escapeHTML(
                                        booking.booking_status ||
                                        "unknown"
                                    )}

                                </span>

                            </div>


                            <div
                                class="booking-details"
                            >

                                <p>

                                    <strong>
                                        📅 Date:
                                    </strong>

                                    ${escapeHTML(
                                        formatDate(
                                            booking.event_date
                                        )
                                    )}

                                </p>


                                <p>

                                    <strong>
                                        ⏰ Time:
                                    </strong>

                                    ${escapeHTML(
                                        formatTime(
                                            booking.event_time
                                        )
                                    )}

                                </p>


                                <p>

                                    <strong>
                                        📍 Venue:
                                    </strong>

                                    ${escapeHTML(
                                        booking.venue ||
                                        "N/A"
                                    )}

                                </p>


                                <p>

                                    <strong>
                                        🎟️ Tickets:
                                    </strong>

                                    ${escapeHTML(
                                        booking.quantity ?? 0
                                    )}

                                </p>


                                <p>

                                    <strong>
                                        💰 Total:
                                    </strong>

                                    ৳${Number(
                                        booking.total_amount || 0
                                    ).toFixed(2)}

                                </p>


                                <p>

                                    <strong>
                                        Booking ID:
                                    </strong>

                                    #${escapeHTML(
                                        booking.id
                                    )}

                                </p>

                            </div>


                            ${
                                isConfirmed &&
                                booking.ticket_code

                                    ?

                                `

                                    <button
                                        class="ticket-btn"
                                        data-booking-id="${escapeHTML(
                                            booking.id
                                        )}"
                                    >

                                        🎫 View Ticket

                                    </button>

                                `

                                    :

                                isPending

                                    ?

                                `

                                    <button
                                        class="ticket-btn pay-now-btn"
                                        data-booking-id="${escapeHTML(
                                            booking.id
                                        )}"
                                    >

                                        💳 Pay Now

                                    </button>

                                    <p
                                        class="
                                            payment-pending
                                        "
                                    >

                                        ⚠️ Payment pending

                                    </p>

                                `

                                    :

                                `

                                    <p
                                        class="
                                            payment-pending
                                        "
                                    >

                                        Payment not completed

                                    </p>

                                `

                            }

                        </div>

                    `;

                }
            ).join("");


        // ===============================
        // VIEW TICKET BUTTONS
        // ===============================

        const ticketButtons =
            container.querySelectorAll(
                ".ticket-btn:not(.pay-now-btn)"
            );


        ticketButtons.forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        const bookingId =
                            button.dataset.bookingId;

                        viewTicket(
                            bookingId
                        );

                    }
                );

            }
        );


        // ===============================
        // PAY NOW BUTTONS
        // ===============================

        const payButtons =
            container.querySelectorAll(
                ".pay-now-btn"
            );


        payButtons.forEach(
            button => {

                button.addEventListener(
                    "click",
                    () => {

                        const bookingId =
                            button.dataset.bookingId;

                        payForBooking(
                            bookingId
                        );

                    }
                );

            }
        );


    } catch (error) {

        console.error(
            "Load bookings error:",
            error
        );


        container.innerHTML = `

            <div class="no-bookings">

                <p style="color:red;">

                    ${escapeHTML(
                        error.message
                    )}

                </p>

            </div>

        `;

    }

}


// ===============================
// PAY FOR PENDING BOOKING
// ===============================

function payForBooking(
    bookingId
) {

    if (!bookingId) {

        alert(
            "Invalid booking ID."
        );

        return;

    }


    window.location.href =
        `payment.html?booking_id=${encodeURIComponent(
            bookingId
        )}`;

}


// ===============================
// VIEW TICKET
// ===============================

function viewTicket(
    bookingId
) {

    window.location.href =
        `ticket.html?booking_id=${encodeURIComponent(
            bookingId
        )}`;

}


// ===============================
// FORMAT DATE
// ===============================

function formatDate(
    dateString
) {

    if (!dateString) {

        return "N/A";

    }


    const date =
        new Date(dateString);


    if (isNaN(date.getTime())) {

        return "N/A";

    }


    return date.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ===============================
// FORMAT TIME
// ===============================

function formatTime(
    timeString
) {

    if (!timeString) {

        return "N/A";

    }


    const parts =
        timeString.split(":");


    if (parts.length < 2) {

        return timeString;

    }


    let hours =
        parseInt(
            parts[0],
            10
        );


    const minutes =
        parts[1];


    if (isNaN(hours)) {

        return timeString;

    }


    const period =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {

        hours = 12;

    }


    return `${hours}:${minutes} ${period}`;

}


// ===============================
// LOGOUT
// ===============================

function logout() {

    localStorage.removeItem(
        "token"
    );

    localStorage.removeItem(
        "user"
    );


    window.location.href =
        "login.html";

}

