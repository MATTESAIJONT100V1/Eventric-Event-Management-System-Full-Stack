
// ===============================
// GET LOGIN INFORMATION
// ===============================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user")
    );


// ===============================
// CHECK LOGIN
// ===============================

if (!token || !user) {

    alert(
        "Please login first."
    );

    window.location.href =
        "login.html";

}


// ===============================
// GET EVENT ID
// ===============================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const eventId =
    urlParams.get("id");


// ===============================
// VARIABLES
// ===============================

const container =
    document.getElementById(
        "bookingContainer"
    );

let eventData = null;


// ===============================
// CHECK EVENT ID
// ===============================

if (!eventId) {

    container.innerHTML = `

        <div class="error-message">

            <h2>
                Event not found
            </h2>

            <p>
                No event ID was provided.
            </p>

        </div>

    `;

} else {

    loadEvent();

}


// ===============================
// LOAD EVENT
// ===============================

async function loadEvent() {

    try {

        const response =
            await fetch(
                `http://localhost:3000/api/events/${eventId}`
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load event"
            );

        }


        eventData = data;


        displayBookingPage(
            data
        );


    } catch (error) {

        console.error(error);


        container.innerHTML = `

            <div class="error-message">

                <h2>
                    Failed to load event
                </h2>

                <p>
                    ${error.message}
                </p>

            </div>

        `;

    }

}


// ===============================
// DISPLAY BOOKING PAGE
// ===============================

function displayBookingPage(
    event
) {

    const availableSeats =
        Number(
            event.available_seats
        );


    document.title =
        `Book ${event.title} - Eventric`;


    if (availableSeats <= 0) {

        container.innerHTML = `

            <div class="error-message">

                <h2>
                    Event Sold Out
                </h2>

                <p>
                    There are no available seats.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML = `

        <h1>
            Book Tickets
        </h1>


        <div class="event-name">

            ${event.title}

        </div>


        <div class="event-summary">

            <div>

                <strong>
                    📅 Date:
                </strong>

                ${formatDate(
                    event.event_date
                )}

            </div>


            <div>

                <strong>
                    ⏰ Time:
                </strong>

                ${formatTime(
                    event.event_time
                )}

            </div>


            <div>

                <strong>
                    📍 Venue:
                </strong>

                ${event.venue}

            </div>


            <div>

                <strong>
                    💰 Price per ticket:
                </strong>

                ৳${event.ticket_price}

            </div>


            <div>

                <strong>
                    🎟️ Available seats:
                </strong>

                ${availableSeats}

            </div>

        </div>


        <div class="quantity-section">

            <label for="quantity">

                Number of Tickets

            </label>


            <input
                type="number"
                id="quantity"
                min="1"
                max="${availableSeats}"
                value="1"
            >

        </div>


        <div class="total-box">

            <span>
                Total Amount
            </span>

            <strong id="totalAmount">

                ৳${event.ticket_price}

            </strong>

        </div>


        <button
            id="confirmBtn"
            class="confirm-btn"
            onclick="confirmBooking()"
        >

            Confirm Booking

        </button>


        <div
            id="message"
            class="message"
        >
        </div>

    `;


    const quantityInput =
        document.getElementById(
            "quantity"
        );


    quantityInput.addEventListener(
        "input",
        updateTotal
    );

}


// ===============================
// UPDATE TOTAL
// ===============================

function updateTotal() {

    const quantityInput =
        document.getElementById(
            "quantity"
        );


    let quantity =
        Number(
            quantityInput.value
        );


    const maxSeats =
        Number(
            eventData.available_seats
        );


    if (quantity < 1) {

        quantity = 1;

        quantityInput.value = 1;

    }


    if (quantity > maxSeats) {

        quantity = maxSeats;

        quantityInput.value =
            maxSeats;

    }


    const price =
        Number(
            eventData.ticket_price
        );


    const total =
        price * quantity;


    document.getElementById(
        "totalAmount"
    ).textContent =
        `৳${total.toFixed(2)}`;

}


// ===============================
// CONFIRM BOOKING
// ===============================

async function confirmBooking() {

    const quantityInput =
        document.getElementById(
            "quantity"
        );

    const message =
        document.getElementById(
            "message"
        );

    const confirmBtn =
        document.getElementById(
            "confirmBtn"
        );


    const quantity =
        Number(
            quantityInput.value
        );


    if (
        !quantity ||
        quantity < 1
    ) {

        message.textContent =
            "Please select at least 1 ticket.";

        message.style.color =
            "#dc3545";

        return;

    }


    if (
        quantity >
        Number(
            eventData.available_seats
        )
    ) {

        message.textContent =
            "Not enough seats available.";

        message.style.color =
            "#dc3545";

        return;

    }


    confirmBtn.disabled =
        true;


    confirmBtn.textContent =
        "Booking...";


    message.textContent =
        "";


    try {

        const response =
            await fetch(
                "http://localhost:3000/api/bookings",
                {
                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`

                    },

                    body: JSON.stringify({

                        event_id:
                            Number(eventId),

                        quantity:
                            quantity

                    })

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Booking failed"
            );

        }


        // ===============================
        // BOOKING SUCCESS
        // ===============================

        message.textContent =
            "Booking successful!";

        message.style.color =
            "#198754";


        confirmBtn.textContent =
            "Proceeding to Payment...";


        // ===============================
        // GO TO PAYMENT PAGE
        // ===============================

        setTimeout(
            function () {

                window.location.href =
                    `payment.html?booking_id=${data.bookingId}`;

            },
            1500
        );


    } catch (error) {

        console.error(error);


        message.textContent =
            error.message ||
            "Booking failed.";

        message.style.color =
            "#dc3545";


        confirmBtn.disabled =
            false;


        confirmBtn.textContent =
            "Confirm Booking";

    }

}


// ===============================
// FORMAT DATE
// ===============================

function formatDate(
    date
) {

    const d =
        new Date(date);


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ===============================
// FORMAT TIME
// ===============================

function formatTime(
    time
) {

    if (!time) {

        return "N/A";

    }


    const parts =
        time.split(":");


    let hours =
        parseInt(parts[0]);


    const minutes =
        parts[1];


    const ampm =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {

        hours = 12;

    }


    return (
        hours +
        ":" +
        minutes +
        " " +
        ampm
    );

}

