
// =========================================================
// EVENTRIC ORGANIZER DASHBOARD
// =========================================================


// =========================================================
// LOGIN
// =========================================================

const token = localStorage.getItem("token");

let user = null;

try {
    user = JSON.parse(
        localStorage.getItem("user")
    );
}
catch (error) {
    user = null;
}


// =========================================================
// CHECK LOGIN
// =========================================================

if (!token || !user) {

    alert("Please login first.");

    window.location.href = "login.html";

}


// =========================================================
// CHECK ROLE
// =========================================================

if (
    user &&
    user.role !== "organizer" &&
    user.role !== "admin"
) {

    alert("Organizer access required.");

    window.location.href = "index.html";

}


// =========================================================
// GET ELEMENTS
// =========================================================

const welcomeText =
    document.getElementById("welcomeText");

const eventForm =
    document.getElementById("eventForm");

const eventMessage =
    document.getElementById("eventMessage");

const eventsContainer =
    document.getElementById("eventsContainer");

const refreshBtn =
    document.getElementById("refreshBtn");

const refreshStatus =
    document.getElementById("refreshStatus");

const logoutBtn =
    document.getElementById("logoutBtn");

const editModal =
    document.getElementById("editModal");

const closeModal =
    document.getElementById("closeModal");

const editForm =
    document.getElementById("editForm");

const editMessage =
    document.getElementById("editMessage");


// =========================================================
// WELCOME MESSAGE
// =========================================================

if (welcomeText && user) {

    welcomeText.textContent =
        "Welcome, " + user.name + "!";

}


// =========================================================
// LOAD MY EVENTS
// =========================================================

async function loadMyEvents() {

    console.log("Loading organizer events...");

    try {

        const response =
            await fetch(
                "http://localhost:3000/api/events/organizer/my-events",
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            "Bearer " + token
                    }
                }
            );


        const data =
            await response.json();


        console.log(
            "Organizer events:",
            data
        );


        if (!response.ok) {

            eventsContainer.innerHTML =
                "<p>" +
                (
                    data.message ||
                    "Failed to load events."
                ) +
                "</p>";

            return false;
        }


        displayEvents(data);

        return true;

    }
    catch (error) {

        console.error(error);

        eventsContainer.innerHTML =
            "<p>Could not connect to server.</p>";

        return false;

    }

}


// =========================================================
// DISPLAY EVENTS
// =========================================================

function displayEvents(events) {

    if (
        !Array.isArray(events) ||
        events.length === 0
    ) {

        eventsContainer.innerHTML =
            "<p>You have no events yet.</p>";

        return;
    }


    eventsContainer.innerHTML = "";


    events.forEach(function (event) {

        const card =
            document.createElement("div");

        card.className =
            "event-card";


        const status =
            String(
                event.status || "active"
            ).toLowerCase();


        const isCancelled =
            status === "cancelled" ||
            status === "canceled";


        const statusText =
            isCancelled
                ? "Cancelled"
                : "Active";


        card.innerHTML = `

            <h3>
                ${escapeHTML(
                    event.title || "Untitled Event"
                )}
            </h3>

            <p>
                <strong>Description:</strong>
                ${escapeHTML(
                    event.description || "N/A"
                )}
            </p>

            <p>
                <strong>Category:</strong>
                ${escapeHTML(
                    event.category || "N/A"
                )}
            </p>

            <p>
                <strong>Date:</strong>
                ${formatDate(event.event_date)}
            </p>

            <p>
                <strong>Time:</strong>
                ${formatTime(event.event_time)}
            </p>

            <p>
                <strong>Venue:</strong>
                ${escapeHTML(
                    event.venue || "N/A"
                )}
            </p>

            <p>
                <strong>Ticket Price:</strong>
                ৳${event.ticket_price ?? 0}
            </p>

            <p>
                <strong>Total Seats:</strong>
                ${event.total_seats ?? 0}
            </p>

            <p>
                <strong>Available Seats:</strong>
                ${event.available_seats ?? 0}
            </p>

            <p>
                <strong>Status:</strong>
                <span class="event-status ${isCancelled ? "cancelled" : "active"}">
                    ${statusText}
                </span>
            </p>

            <div class="event-actions">

                <button
                    type="button"
                    class="edit-btn">
                    Edit
                </button>

                ${
                    isCancelled
                    ?
                    `
                    <button
                        type="button"
                        class="activate-btn">
                        Activate
                    </button>
                    `
                    :
                    `
                    <button
                        type="button"
                        class="cancel-btn">
                        Cancel
                    </button>
                    `
                }

            </div>
        `;


        // =================================================
        // EDIT BUTTON
        // =================================================

        card
            .querySelector(".edit-btn")
            .addEventListener(
                "click",
                function () {

                    editEvent(event.id);

                }
            );


        // =================================================
        // ACTIVATE / CANCEL BUTTON
        // =================================================

        if (isCancelled) {

            card
                .querySelector(".activate-btn")
                .addEventListener(
                    "click",
                    function () {

                        activateEvent(event.id);

                    }
                );

        }
        else {

            card
                .querySelector(".cancel-btn")
                .addEventListener(
                    "click",
                    function () {

                        cancelEvent(event.id);

                    }
                );

        }


        eventsContainer.appendChild(card);

    });

}


// =========================================================
// ESCAPE HTML
// =========================================================

function escapeHTML(value) {

    if (value === null || value === undefined) {
        return "";
    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// =========================================================
// DATE FORMAT
// =========================================================

function formatDate(date) {

    if (!date) {
        return "N/A";
    }


    const d =
        new Date(date);


    if (isNaN(d.getTime())) {
        return "N/A";
    }


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// =========================================================
// TIME FORMAT — 12 HOUR
// =========================================================

function formatTime(time) {

    if (!time) {
        return "N/A";
    }


    const parts =
        String(time).split(":");


    let hours =
        parseInt(parts[0], 10);


    const minutes =
        parts[1] || "00";


    if (isNaN(hours)) {
        return "N/A";
    }


    const ampm =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {
        hours = 12;
    }


    return (
        hours +
        ":" +
        minutes +
        " " +
        ampm
    );

}


// =========================================================
// CREATE EVENT
// =========================================================

eventForm.addEventListener(
    "submit",
    async function (e) {

        e.preventDefault();


        const title =
            document.getElementById(
                "title"
            ).value.trim();


        const description =
            document.getElementById(
                "description"
            ).value.trim();


        const category =
            document.getElementById(
                "category"
            ).value;


        const eventDate =
            document.getElementById(
                "event_date"
            ).value;


        const eventTime =
            document.getElementById(
                "event_time"
            ).value;


        const venue =
            document.getElementById(
                "venue"
            ).value.trim();


        const ticketPrice =
            document.getElementById(
                "ticket_price"
            ).value || 0;


        const totalSeats =
            document.getElementById(
                "total_seats"
            ).value;


        const image =
            document.getElementById(
                "image"
            ).value.trim();


        // =================================================
        // FRONTEND VALIDATION
        // =================================================

        if (
            !title ||
            !category ||
            !eventDate ||
            !eventTime ||
            !venue ||
            !totalSeats
        ) {

            eventMessage.textContent =
                "Please provide all required event information.";

            return;
        }


        try {

            const eventData = {

                title:
                    title,

                description:
                    description,

                category:
                    category,

                event_date:
                    eventDate,

                event_time:
                    eventTime,

                venue:
                    venue,

                ticket_price:
                    ticketPrice,

                total_seats:
                    totalSeats,

                image:
                    image

            };


            const response =
                await fetch(
                    "http://localhost:3000/api/events/create",
                    {

                        method: "POST",

                        headers: {

                            "Content-Type":
                                "application/json",

                            "Authorization":
                                "Bearer " + token

                        },

                        body:
                            JSON.stringify(eventData)

                    }
                );


            const data =
                await response.json();


            if (!response.ok) {

                eventMessage.textContent =
                    data.message ||
                    "Failed to create event.";

                return;
            }


            eventMessage.textContent =
                "Event created successfully!";


            eventForm.reset();


            await loadMyEvents();

        }
        catch (error) {

            console.error(error);

            eventMessage.textContent =
                "Could not connect to server.";

        }

    }
);


// =========================================================
// EDIT EVENT
// =========================================================

async function editEvent(eventId) {

    try {

        const response =
            await fetch(
                "http://localhost:3000/api/events/" +
                eventId,
                {
                    method: "GET",

                    headers: {
                        "Authorization":
                            "Bearer " + token
                    }
                }
            );


        const event =
            await response.json();


        if (!response.ok) {

            alert(
                event.message ||
                "Failed to load event."
            );

            return;
        }


        // =================================================
        // STORE EVENT ID
        // =================================================

        document.getElementById(
            "editEventId"
        ).value =
            event.id;


        // =================================================
        // LOAD FORM VALUES
        // =================================================

        document.getElementById(
            "editTitle"
        ).value =
            event.title || "";


        document.getElementById(
            "editDescription"
        ).value =
            event.description || "";


        document.getElementById(
            "editCategory"
        ).value =
            event.category || "";


        // DATE

        let editDate = "";

        if (event.event_date) {

            editDate =
                String(
                    event.event_date
                ).split("T")[0];

        }

        document.getElementById(
            "editDate"
        ).value =
            editDate;


        // TIME

        let editTime = "";

        if (event.event_time) {

            editTime =
                String(
                    event.event_time
                ).substring(0, 5);

        }

        document.getElementById(
            "editTime"
        ).value =
            editTime;


        // VENUE

        document.getElementById(
            "editVenue"
        ).value =
            event.venue || "";


        // PRICE

        document.getElementById(
            "editPrice"
        ).value =
            event.ticket_price ?? 0;


        // IMAGE

        document.getElementById(
            "editImage"
        ).value =
            event.image || "";


        // =================================================
        // KEEP TOTAL SEATS
        // =================================================

        /*
         The current Edit form does not have a
         total_seats input.

         Store the existing value on the form
         so Save Changes can send it to the API.
        */

        editForm.dataset.totalSeats =
            event.total_seats ?? 0;


        editForm.dataset.status =
            event.status || "active";


        editMessage.textContent = "";


        editModal.style.display =
            "flex";

    }
    catch (error) {

        console.error(error);

        alert(
            "Could not load event details."
        );

    }

}


// =========================================================
// SAVE EDIT
// =========================================================

editForm.addEventListener(
    "submit",
    async function (e) {

        e.preventDefault();


        // =================================================
        // GET EVENT ID
        // =================================================

        const eventId =
            document.getElementById(
                "editEventId"
            ).value;


        // =================================================
        // GET FORM VALUES
        // =================================================

        const title =
            document.getElementById(
                "editTitle"
            ).value.trim();


        const description =
            document.getElementById(
                "editDescription"
            ).value.trim();


        const category =
            document.getElementById(
                "editCategory"
            ).value;


        const date =
            document.getElementById(
                "editDate"
            ).value;


        const time =
            document.getElementById(
                "editTime"
            ).value;


        const location =
            document.getElementById(
                "editVenue"
            ).value.trim();


        const price =
            document.getElementById(
                "editPrice"
            ).value || 0;


        const image =
            document.getElementById(
                "editImage"
            ).value.trim();


        const totalSeats =
            editForm.dataset.totalSeats || 0;


        const status =
            editForm.dataset.status || "active";


        // =================================================
        // VALIDATION
        // =================================================

        if (
            !eventId ||
            !title ||
            !category ||
            !date ||
            !time ||
            !location ||
            !totalSeats
        ) {

            editMessage.textContent =
                "Please provide all required event information.";

            return;
        }


        // =================================================
        // IMPORTANT
        // SEND FIELD NAMES EXPECTED BY
        // THE EXISTING UPDATE API
        // =================================================

        const updatedEvent = {

            title:
                title,

            description:
                description,

            category:
                category,

            date:
                date,

            time:
                time,

            location:
                location,

            price:
                price,

            total_seats:
                totalSeats,

            image:
                image,

            status:
                status

        };


        console.log(
            "Updating event:",
            updatedEvent
        );


        try {

            const response =
                await fetch(
                    "http://localhost:3000/api/events/" +
                    eventId,
                    {

                        method: "PUT",

                        headers: {

                            "Content-Type":
                                "application/json",

                            "Authorization":
                                "Bearer " + token

                        },

                        body:
                            JSON.stringify(
                                updatedEvent
                            )

                    }
                );


            const data =
                await response.json();


            console.log(
                "Update response:",
                data
            );


            if (!response.ok) {

                editMessage.textContent =
                    data.message ||
                    "Failed to update event.";

                return;
            }


            editMessage.textContent =
                "Event updated successfully!";


            alert(
                "Event updated successfully!"
            );


            editModal.style.display =
                "none";


            await loadMyEvents();

        }
        catch (error) {

            console.error(error);

            editMessage.textContent =
                "Could not connect to server.";

        }

    }
);


// =========================================================
// CLOSE MODAL
// =========================================================

closeModal.addEventListener(
    "click",
    function () {

        editModal.style.display =
            "none";

    }
);


// =========================================================
// CLICK OUTSIDE MODAL
// =========================================================

editModal.addEventListener(
    "click",
    function (e) {

        if (e.target === editModal) {

            editModal.style.display =
                "none";

        }

    }
);


// =========================================================
// CANCEL EVENT
// =========================================================

async function cancelEvent(eventId) {

    const confirmCancel =
        confirm(
            "Are you sure you want to cancel this event?"
        );


    if (!confirmCancel) {
        return;
    }


    try {

        const response =
            await fetch(
                "http://localhost:3000/api/events/" +
                eventId +
                "/cancel",
                {

                    method: "PUT",

                    headers: {

                        "Authorization":
                            "Bearer " + token

                    }

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            alert(
                data.message ||
                "Failed to cancel event."
            );

            return;
        }


        alert(
            "Event cancelled successfully!"
        );


        await loadMyEvents();

    }
    catch (error) {

        console.error(error);

        alert(
            "Could not connect to server."
        );

    }

}


// =========================================================
// ACTIVATE EVENT
// =========================================================

async function activateEvent(eventId) {

    const confirmActivate =
        confirm(
            "Are you sure you want to activate this event again?"
        );


    if (!confirmActivate) {
        return;
    }


    try {

        const response =
            await fetch(
                "http://localhost:3000/api/events/" +
                eventId +
                "/activate",
                {

                    method: "PUT",

                    headers: {

                        "Authorization":
                            "Bearer " + token

                    }

                }
            );


        const data =
            await response.json();


        if (!response.ok) {

            alert(
                data.message ||
                "Failed to activate event."
            );

            return;
        }


        alert(
            "Event activated successfully!"
        );


        await loadMyEvents();

    }
    catch (error) {

        console.error(error);

        alert(
            "Could not connect to server."
        );

    }

}


// =========================================================
// REFRESH BUTTON
// =========================================================

refreshBtn.addEventListener(
    "click",
    async function () {

        if (refreshBtn.disabled) {
            return;
        }


        refreshBtn.disabled = true;


        refreshStatus.textContent =
            "Updating...";


        await new Promise(
            function (resolve) {

                setTimeout(
                    resolve,
                    500
                );

            }
        );


        const success =
            await loadMyEvents();


        if (success) {

            refreshStatus.textContent =
                "Updated ✓";


            setTimeout(
                function () {

                    refreshStatus.textContent =
                        "";

                },
                1500
            );

        }
        else {

            refreshStatus.textContent =
                "Failed";

        }


        refreshBtn.disabled = false;

    }
);


// =========================================================
// LOGOUT
// =========================================================

logoutBtn.addEventListener(
    "click",
    function () {

        localStorage.removeItem("token");

        localStorage.removeItem("user");

        window.location.href =
            "login.html";

    }
);


// =========================================================
// INITIAL LOAD
// =========================================================

loadMyEvents();
