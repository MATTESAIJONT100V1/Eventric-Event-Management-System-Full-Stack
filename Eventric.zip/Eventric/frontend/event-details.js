// ======================================
// EVENTRIC - EVENT DETAILS
// ======================================

const API_BASE_URL = "http://localhost:3000";

// ======================================
// GET EVENT ID
// ======================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const eventId =
    urlParams.get("id");


// ======================================
// EVENT CONTAINER
// ======================================

const container =
    document.getElementById(
        "eventContainer"
    );


// ======================================
// CHECK CONTAINER
// ======================================

if (!container) {

    console.error(
        "eventContainer was not found."
    );

}


// ======================================
// CHECK EVENT ID
// ======================================

if (!eventId) {

    showError(
        "Event not found",
        "No event ID was provided."
    );

} else if (
    !/^\d+$/.test(eventId) ||
    Number(eventId) <= 0
) {

    showError(
        "Invalid Event",
        "The event ID is invalid."
    );

} else {

    loadEvent();

}


// ======================================
// LOAD EVENT
// ======================================

async function loadEvent() {

    try {

        container.innerHTML = `
            <div class="loading">
                Loading event details...
            </div>
        `;


        const response =
            await fetch(
                `${API_BASE_URL}/api/events/${encodeURIComponent(eventId)}`
            );


        let data = {};

        try {

            data =
                await response.json();

        } catch (error) {

            data = {};

        }


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load event."
            );

        }


        displayEvent(data);

    } catch (error) {

        console.error(
            "Failed to load event:",
            error
        );

        showError(
            "Failed to Load Event",
            error.message
        );

    }

}


// ======================================
// DISPLAY EVENT
// ======================================

function displayEvent(event) {

    document.title =
        `${event.title || "Event"} - Eventric`;


    const availableSeats =
        Math.max(
            0,
            Number(
                event.available_seats ?? 0
            )
        );


    const totalSeats =
        Math.max(
            0,
            Number(
                event.total_seats ?? 0
            )
        );


    const ticketPrice =
        Math.max(
            0,
            Number(
                event.ticket_price ?? 0
            )
        );


    const soldOut =
        availableSeats <= 0;


    container.innerHTML = `

        <div class="event-details-header">

            <span class="event-category">

                ${escapeHtml(
                    event.category ||
                    "Event"
                )}

            </span>


            <h1>

                ${escapeHtml(
                    event.title ||
                    "Untitled Event"
                )}

            </h1>

        </div>


        <p class="event-description">

            ${escapeHtml(
                event.description ||
                "No description available."
            )}

        </p>


        <div class="details-grid">


            <div class="detail-box">

                <strong>
                    📅 Date
                </strong>

                <span>
                    ${formatDate(
                        event.event_date
                    )}
                </span>

            </div>


            <div class="detail-box">

                <strong>
                    ⏰ Time
                </strong>

                <span>
                    ${formatTime(
                        event.event_time
                    )}
                </span>

            </div>


            <div class="detail-box">

                <strong>
                    📍 Venue
                </strong>

                <span>
                    ${escapeHtml(
                        event.venue ||
                        "N/A"
                    )}
                </span>

            </div>


            <div class="detail-box">

                <strong>
                    💰 Ticket Price
                </strong>

                <span>
                    ৳${ticketPrice.toFixed(2)}
                </span>

            </div>


            <div class="detail-box">

                <strong>
                    🎟️ Available Seats
                </strong>

                <span class="${
                    availableSeats <= 10
                        ? "seats-low"
                        : "seats-normal"
                }">

                    ${availableSeats}

                </span>

            </div>


            <div class="detail-box">

                <strong>
                    📊 Total Seats
                </strong>

                <span>
                    ${totalSeats}
                </span>

            </div>


        </div>


        <div class="booking-area">

            <button
                type="button"
                class="book-btn"
                id="bookBtn"
                onclick="bookEvent()"
                ${soldOut ? "disabled" : ""}
            >

                ${
                    soldOut
                        ? "Sold Out"
                        : "Book Tickets"
                }

            </button>


            ${
                soldOut
                    ? `
                        <p class="sold-out-message">
                            Sorry, all seats for this event
                            have been booked.
                        </p>
                    `
                    : `
                        <p class="booking-note">
                            Secure your ticket before
                            the available seats run out.
                        </p>
                    `
            }

        </div>

    `;

}


// ======================================
// FORMAT DATE
// ======================================

function formatDate(date) {

    if (!date) {
        return "N/A";
    }


    const d =
        new Date(date);


    if (
        Number.isNaN(
            d.getTime()
        )
    ) {

        return "N/A";

    }


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ======================================
// FORMAT TIME
// ======================================

function formatTime(time) {

    if (!time) {
        return "N/A";
    }


    const parts =
        String(time).split(":");


    let hours =
        parseInt(
            parts[0],
            10
        );


    const minutes =
        parts[1] || "00";


    if (
        Number.isNaN(hours)
    ) {

        return "N/A";

    }


    const ampm =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12;


    if (hours === 0) {
        hours = 12;
    }


    return `${hours}:${minutes} ${ampm}`;

}


// ======================================
// BOOK EVENT
// ======================================

function bookEvent() {

    if (!eventId) {

        alert(
            "Event ID is missing."
        );

        return;

    }


    window.location.href =
        `book-ticket.html?id=${encodeURIComponent(eventId)}`;

}


// ======================================
// SHOW ERROR
// ======================================

function showError(
    title,
    message
) {

    if (!container) {
        return;
    }


    container.innerHTML = `

        <div class="error-message">

            <div class="error-icon">
                ⚠️
            </div>

            <h2>
                ${escapeHtml(title)}
            </h2>

            <p>
                ${escapeHtml(message)}
            </p>


            <div class="error-actions">

                <a
                    href="index.html#events"
                    class="back-home-btn"
                >
                    ← Back to Events
                </a>

            </div>

        </div>

    `;

}


// ======================================
// ESCAPE HTML
// ======================================

function escapeHtml(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}