// ======================================
// EVENTRIC - MAIN JS
// ======================================

const API_BASE_URL =
    "http://localhost:3000";

let allEvents = [];


// ======================================
// LOAD EVENTS
// ======================================

async function loadEvents() {

    const container =
        document.getElementById("eventContainer");

    if (!container) {

        console.error(
            "eventContainer not found."
        );

        return;
    }


    container.innerHTML = `
        <div class="loading">
            Loading events...
        </div>
    `;


    try {

        const response =
            await fetch(
                `${API_BASE_URL}/api/events`
            );


        let data;


        try {

            data =
                await response.json();

        } catch (error) {

            throw new Error(
                "Invalid response from server."
            );

        }


        console.log(
            "Events API Response:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load events."
            );

        }


        // ==================================
        // API RETURNS ARRAY
        // ==================================

        if (Array.isArray(data)) {

            allEvents = data;

        }


        // ==================================
        // SUPPORT { events: [] }
        // ==================================

        else if (
            Array.isArray(data.events)
        ) {

            allEvents =
                data.events;

        }


        // ==================================
        // SUPPORT { data: [] }
        // ==================================

        else if (
            Array.isArray(data.data)
        ) {

            allEvents =
                data.data;

        }


        else {

            throw new Error(
                "Invalid events data received from server."
            );

        }


        displayEvents(allEvents);

    }


    catch (error) {

        console.error(
            "Failed to load events:",
            error
        );


        container.innerHTML = `

            <div class="error-message">

                <div class="error-icon">
                    ⚠️
                </div>

                <h2>
                    Failed to Load Events
                </h2>

                <p>
                    ${escapeHtml(
                        error.message
                    )}
                </p>

                <button
                    type="button"
                    class="retry-btn"
                    onclick="loadEvents()"
                >
                    Try Again
                </button>

            </div>

        `;

    }

}


// ======================================
// DISPLAY EVENTS
// ======================================

function displayEvents(events) {

    const container =
        document.getElementById(
            "eventContainer"
        );


    if (!container) {
        return;
    }


    if (
        !Array.isArray(events) ||
        events.length === 0
    ) {

        container.innerHTML = `

            <div class="empty-events">

                <div class="empty-events-icon">
                    🎟️
                </div>

                <h2>
                    No Events Found
                </h2>

                <p>
                    There are currently no active events.
                </p>

            </div>

        `;

        return;

    }


    container.innerHTML = "";


    events.forEach(event => {


        const eventId =
            Number(event.id);


        // ==================================
        // DATABASE FIELD SUPPORT
        // ==================================

        const eventDate =
            event.event_date ||
            event.date;


        const eventTime =
            event.event_time ||
            event.time ||
            "";


        const venue =
            event.venue ||
            event.location ||
            "N/A";


        const ticketPrice =
            event.ticket_price ??
            event.price ??
            0;


        const category =
            event.category ||
            "Event";


        const title =
            event.title ||
            "Untitled Event";


        const description =
            event.description ||
            "No description available.";


        const availableSeats =
            event.available_seats ??
            event.seats ??
            null;


        // ==================================
        // CREATE CARD
        // ==================================

        const card =
            document.createElement(
                "article"
            );


        card.className =
            "event-card";


        card.innerHTML = `

            <div class="event-image">

                <span>
                    ${escapeHtml(
                        category
                    )}
                </span>

            </div>


            <div class="event-info">


                <p class="event-date">

                    📅
                    ${formatDate(
                        eventDate
                    )}

                    ${
                        eventTime
                            ? ` • ${formatTime(eventTime)}`
                            : ""
                    }

                </p>


                <h3>

                    ${escapeHtml(
                        title
                    )}

                </h3>


                <p class="event-description">

                    ${escapeHtml(
                        description
                    )}

                </p>


                <div class="event-bottom">


                    <span>

                        📍
                        ${escapeHtml(
                            venue
                        )}

                    </span>


                    <span>

                        ৳${Number(
                            ticketPrice
                        ).toFixed(2)}

                    </span>

                </div>


                ${
                    availableSeats !== null
                        ? `
                            <p class="available-seats">
                                ${Number(
                                    availableSeats
                                )} seats available
                            </p>
                          `
                        : ""
                }


                <button
                    type="button"
                    class="details-btn"
                    onclick="viewEvent(${eventId})"
                >
                    View Details
                </button>


            </div>

        `;


        container.appendChild(card);

    });

}


// ======================================
// FORMAT DATE
// ======================================

function formatDate(date) {

    if (!date) {
        return "N/A";
    }


    const d =
        new Date(date);


    if (
        Number.isNaN(
            d.getTime()
        )
    ) {

        return String(date);

    }


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ======================================
// FORMAT TIME
// ======================================

function formatTime(time) {

    if (!time) {
        return "";
    }


    const parts =
        String(time).split(":");


    if (parts.length < 2) {
        return time;
    }


    let hours =
        Number(parts[0]);


    const minutes =
        parts[1];


    const ampm =
        hours >= 12
            ? "PM"
            : "AM";


    hours =
        hours % 12 ||
        12;


    return `${hours}:${minutes} ${ampm}`;

}


// ======================================
// VIEW EVENT
// ======================================

function viewEvent(id) {

    const numericId =
        Number(id);


    if (
        !Number.isInteger(
            numericId
        ) ||
        numericId <= 0
    ) {

        alert(
            "Unable to open this event. Event ID is invalid."
        );

        return;

    }


    window.location.href =
        `event-details.html?id=${encodeURIComponent(
            numericId
        )}`;

}


// ======================================
// SEARCH EVENTS
// ======================================

function searchEvents() {

    const searchInput =
        document.getElementById(
            "searchInput"
        );


    const categoryFilter =
        document.getElementById(
            "categoryFilter"
        );


    if (
        !searchInput ||
        !categoryFilter
    ) {

        return;

    }


    const searchText =
        searchInput.value
            .trim()
            .toLowerCase();


    const selectedCategory =
        categoryFilter.value
            .trim()
            .toLowerCase();


    const filteredEvents =
        allEvents.filter(
            event => {


                const title =
                    (
                        event.title ||
                        ""
                    )
                    .toLowerCase();


                const description =
                    (
                        event.description ||
                        ""
                    )
                    .toLowerCase();


                const venue =
                    (
                        event.venue ||
                        event.location ||
                        ""
                    )
                    .toLowerCase();


                const category =
                    (
                        event.category ||
                        ""
                    )
                    .toLowerCase();


                const matchesSearch =
                    title.includes(
                        searchText
                    ) ||
                    description.includes(
                        searchText
                    ) ||
                    venue.includes(
                        searchText
                    );


                const matchesCategory =
                    selectedCategory ===
                        "all" ||
                    selectedCategory ===
                        "" ||
                    category ===
                        selectedCategory;


                return (
                    matchesSearch &&
                    matchesCategory
                );

            }
        );


    displayEvents(
        filteredEvents
    );

}


// ======================================
// ESCAPE HTML
// ======================================

function escapeHtml(value) {

    return String(value)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// ======================================
// START
// ======================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        loadEvents();

    }
);