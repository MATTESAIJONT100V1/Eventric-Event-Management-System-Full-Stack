
// ======================================
// GET LOGIN INFORMATION
// ======================================

const token =
    localStorage.getItem("token");

const user =
    JSON.parse(
        localStorage.getItem("user")
    );


// ======================================
// CHECK LOGIN
// ======================================

if (!token || !user) {

    alert("Please login first.");

    window.location.href =
        "login.html";

}


// ======================================
// GET BOOKING ID
// ======================================

const urlParams =
    new URLSearchParams(
        window.location.search
    );

const bookingId =
    urlParams.get("booking_id");

console.log(
    "BOOKING ID:",
    bookingId
);

// ======================================
// CHECK BOOKING ID
// ======================================

if (!bookingId) {

    document.getElementById(
        "paymentInfo"
    ).innerHTML = `

        <h3>Booking ID is missing.</h3>

        <p>
            Please return to your booking page.
        </p>

    `;

} else {

    loadBooking();

}


// ======================================
// LOAD BOOKING
// ======================================

async function loadBooking() {

    try {

        const response =
            await fetch(
                "http://localhost:3000/api/bookings/my-bookings",
                {
                    method: "GET",

                    headers: {

                        "Authorization":
                            `Bearer ${token}`

                    }

                }
            );


        const data =
            await response.json();


        console.log(
            "MY BOOKINGS:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Failed to load bookings"
            );

        }


        // ======================================
        // FIND BOOKING
        // ======================================

        const booking =
            data.find(
                item =>
                    Number(item.id) ===
                    Number(bookingId)
            );


        if (!booking) {

            throw new Error(
                "Booking not found"
            );

        }


        // ======================================
        // DISPLAY BOOKING
        // ======================================

        document.getElementById(
            "paymentInfo"
        ).innerHTML = `

            <p>
                <strong>Booking ID:</strong>
                #${booking.id}
            </p>

            <p>
                <strong>Event:</strong>
                ${booking.title}
            </p>

            <p>
                <strong>Date:</strong>
                ${formatDate(
                    booking.event_date
                )}
            </p>

            <p>
                <strong>Time:</strong>
                ${formatTime(
                    booking.event_time
                )}
            </p>

            <p>
                <strong>Venue:</strong>
                ${booking.venue || "N/A"}
            </p>

            <p>
                <strong>Tickets:</strong>
                ${booking.quantity}
            </p>

            <p>
                <strong>Total Amount:</strong>
                ৳${booking.total_amount}
            </p>

            <p>
                <strong>Booking Status:</strong>
                ${booking.booking_status}
            </p>

        `;


    } catch (error) {

        console.error(
            "LOAD BOOKING ERROR:",
            error
        );


        document.getElementById(
            "paymentInfo"
        ).innerHTML = `

            <h3>
                Failed to load booking
            </h3>

            <p>
                ${error.message}
            </p>

        `;

    }

}


// ======================================
// MAKE PAYMENT
// ======================================

async function makePayment() {

    if (!bookingId) {

        alert(
            "Booking ID is missing."
        );

        return;

    }


    // ======================================
    // GET PAYMENT METHOD
    // ======================================

    const selectedPayment =
        document.querySelector(
            'input[name="paymentMethod"]:checked'
        );


    if (!selectedPayment) {

        alert(
            "Please select a payment method."
        );

        return;

    }


    const paymentMethod =
        selectedPayment.value;


    // ======================================
    // DISABLE BUTTON
    // ======================================

    const payButton =
        document.getElementById(
            "payButton"
        );

    payButton.disabled = true;

    payButton.textContent =
        "Processing...";


    const message =
        document.getElementById(
            "message"
        );


    message.textContent =
        "Processing payment...";


    try {

        // ======================================
        // SEND PAYMENT
        // ======================================

        const response =
            await fetch(
                "http://localhost:3000/api/payments",
                {
                    method: "POST",

                    headers: {

                        "Content-Type":
                            "application/json",

                        "Authorization":
                            `Bearer ${token}`

                    },

                    body: JSON.stringify({

                        booking_id:
                            Number(bookingId),

                        payment_method:
                            paymentMethod

                    })

                }
            );


        const data =
            await response.json();


        console.log(
            "PAYMENT RESPONSE:",
            data
        );


        if (!response.ok) {

            throw new Error(
                data.message ||
                "Payment failed"
            );

        }


        // ======================================
        // SUCCESS
        // ======================================

        message.innerHTML = `

            <div>

                <h3>
                    ✅ Payment Successful!
                </h3>

                <p>
                    Booking Confirmed!
                </p>

                <p>
                    Transaction ID:
                    ${data.transactionId}
                </p>

            </div>

        `;


        // ======================================
        // GO TO TICKET
        // ======================================

        setTimeout(
            () => {

                window.location.href =
                    `ticket.html?booking_id=${data.bookingId}`;

            },
            2000
        );


    } catch (error) {

        console.error(
            "PAYMENT ERROR:",
            error
        );


        message.innerHTML = `

            <div>

                <h3>
                    ❌ Payment Failed
                </h3>

                <p>
                    ${error.message}
                </p>

            </div>

        `;


        payButton.disabled = false;

        payButton.textContent =
            "Pay Now";

    }

}


// ======================================
// FORMAT DATE
// ======================================

function formatDate(date) {

    if (!date) {

        return "N/A";

    }


    const d =
        new Date(date);


    return d.toLocaleDateString(
        "en-GB",
        {
            day: "2-digit",
            month: "long",
            year: "numeric"
        }
    );

}


// ======================================
// FORMAT TIME
// ======================================

function formatTime(time) {

    if (!time) {

        return "N/A";

    }


    const parts =
        time.split(":");


    let hour =
        parseInt(parts[0]);


    const minute =
        parts[1];


    const ampm =
        hour >= 12
            ? "PM"
            : "AM";


    hour =
        hour % 12 || 12;


    return `${hour}:${minute} ${ampm}`;

}

