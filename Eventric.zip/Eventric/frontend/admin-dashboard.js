// ======================================
// EVENTRIC ADMIN DASHBOARD
// ======================================


// ======================================
// API BASE URL
// ======================================

const API_BASE_URL = "http://localhost:3000";


// ======================================
// LOGIN INFORMATION
// ======================================

const token = localStorage.getItem("token");

let user = null;

try {

    user = JSON.parse(
        localStorage.getItem("user")
    );

} catch (error) {

    user = null;

}


// ======================================
// CHECK LOGIN
// ======================================

if (!token || !user) {

    alert("Please login first.");

    window.location.href = "login.html";

}


// ======================================
// CHECK ADMIN
// ======================================

if (
    user &&
    String(user.role)
        .trim()
        .toLowerCase() !== "admin"
) {

    alert("Admin access required.");

    window.location.href = "index.html";

}


// ======================================
// DISPLAY ADMIN NAME
// ======================================

document.addEventListener(
    "DOMContentLoaded",
    () => {

        const adminName =
            document.getElementById("adminName");

        if (adminName && user) {

            adminName.textContent =
                user.name ||
                user.full_name ||
                user.email ||
                "Admin";

        }

    }
);


// ======================================
// ADMIN FETCH
// ======================================

async function adminFetch(
    url,
    options = {}
) {

    const response =
        await fetch(
            API_BASE_URL + url,
            {

                ...options,

                headers: {

                    ...(options.headers || {}),

                    "Content-Type":
                        "application/json",

                    "Authorization":
                        `Bearer ${token}`

                }

            }
        );


    let data = {};

    try {

        data = await response.json();

    } catch (error) {

        data = {};

    }


    if (!response.ok) {

        throw new Error(
            data.message ||
            "Request failed"
        );

    }


    return data;

}


// ======================================
// DATE
// DATABASE -> DISPLAY
// ======================================

function formatDateForEdit(date) {

    if (!date) {
        return "";
    }

    const value =
        String(date).substring(0, 10);

    const parts =
        value.split("-");

    if (parts.length !== 3) {
        return value;
    }

    return (
        parts[2] +
        "/" +
        parts[1] +
        "/" +
        parts[0]
    );

}


// ======================================
// DATE
// DISPLAY -> DATABASE
// ======================================

function convertDateToDatabaseFormat(date) {

    if (!date) {
        return "";
    }

    const value =
        String(date).trim();

    if (
        /^\d{4}-\d{2}-\d{2}$/.test(value)
    ) {

        return value;

    }

    const parts =
        value.split("/");

    if (parts.length !== 3) {
        return "";
    }

    let day =
        parts[0].trim();

    let month =
        parts[1].trim();

    let year =
        parts[2].trim();

    if (day.length === 1) {
        day = "0" + day;
    }

    if (month.length === 1) {
        month = "0" + month;
    }

    if (
        year.length !== 4 ||
        day.length !== 2 ||
        month.length !== 2
    ) {

        return "";

    }

    return (
        year +
        "-" +
        month +
        "-" +
        day
    );

}


// ======================================
// TIME
// DATABASE -> 12 HOUR
// ======================================

function formatTime12Hour(time) {

    if (!time) {
        return "";
    }

    const value =
        String(time).substring(0, 5);

    const parts =
        value.split(":");

    if (parts.length < 2) {
        return value;
    }

    let hours =
        Number(parts[0]);

    const minutes =
        parts[1];

    if (Number.isNaN(hours)) {
        return value;
    }

    const period =
        hours >= 12
            ? "PM"
            : "AM";

    hours =
        hours % 12;

    if (hours === 0) {
        hours = 12;
    }

    return (
        String(hours).padStart(2, "0") +
        ":" +
        minutes +
        " " +
        period
    );

}


// ======================================
// TIME
// 12 HOUR -> DATABASE
// ======================================

function convertTimeToDatabaseFormat(time) {

    if (!time) {
        return "";
    }

    const value =
        String(time)
            .trim()
            .toUpperCase();

    if (
        /^\d{2}:\d{2}$/.test(value)
    ) {

        return value;

    }

    const match =
        value.match(
            /^(\d{1,2}):(\d{2})\s*(AM|PM)$/
        );

    if (!match) {
        return "";
    }

    let hours =
        Number(match[1]);

    const minutes =
        match[2];

    const period =
        match[3];

    if (
        hours < 1 ||
        hours > 12
    ) {

        return "";

    }

    if (
        period === "AM" &&
        hours === 12
    ) {

        hours = 0;

    }

    if (
        period === "PM" &&
        hours !== 12
    ) {

        hours += 12;

    }

    return (
        String(hours).padStart(2, "0") +
        ":" +
        minutes
    );

}


// ======================================
// FORMAT MONEY
// ======================================

function formatMoney(amount) {

    const number =
        Number(amount || 0);

    return (
        "৳ " +
        number.toFixed(2)
    );

}


// ======================================
// FORMAT TABLE DATE
// ======================================

function formatTableDate(date) {

    if (!date) {
        return "N/A";
    }

    const value =
        String(date).substring(0, 10);

    const parts =
        value.split("-");

    if (parts.length !== 3) {
        return value;
    }

    return (
        parts[2] +
        "/" +
        parts[1] +
        "/" +
        parts[0]
    );

}


// ======================================
// FORMAT STATUS
// ======================================

function formatStatus(status) {

    if (!status) {
        return "N/A";
    }

    return (
        String(status).charAt(0).toUpperCase() +
        String(status).slice(1)
    );

}


// ======================================
// ESCAPE HTML
// ======================================

function escapeHtml(value) {

    if (
        value === null ||
        value === undefined
    ) {

        return "";

    }

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");

}


// ======================================
// LOADING
// ======================================

function showLoading(container, text) {

    container.innerHTML = `

        <div class="admin-loading">

            <div class="loading-spinner"></div>

            <span>
                ${escapeHtml(text)}
            </span>

        </div>

    `;

}


// ======================================
// EMPTY
// ======================================

function showEmpty(
    container,
    icon,
    text
) {

    container.innerHTML = `

        <div class="admin-empty">

            <div class="empty-icon">
                ${icon}
            </div>

            <strong>
                ${escapeHtml(text)}
            </strong>

            <small>
                No records are available right now.
            </small>

        </div>

    `;

}


// ======================================
// STATISTICS
// ======================================

async function loadStats() {

    try {

        const data =
            await adminFetch(
                "/api/admin/stats"
            );

        animateNumber(
            "totalUsers",
            data.total_users || 0
        );

        animateNumber(
            "totalEvents",
            data.total_events || 0
        );

        animateNumber(
            "totalBookings",
            data.total_bookings || 0
        );

        animateNumber(
            "totalPayments",
            data.total_payments || 0
        );

        animateNumber(
            "totalTickets",
            data.total_tickets || 0
        );

    } catch (error) {

        console.error(
            "LOAD STATS ERROR:",
            error
        );

    }

}


// ======================================
// ANIMATE NUMBER
// ======================================

function animateNumber(
    elementId,
    target
) {

    const element =
        document.getElementById(
            elementId
        );

    if (!element) {
        return;
    }

    const finalValue =
        Number(target) || 0;

    const duration = 600;

    const startTime =
        performance.now();

    function update(currentTime) {

        const progress =
            Math.min(
                (
                    currentTime -
                    startTime
                ) / duration,
                1
            );

        const value =
            Math.floor(
                progress *
                finalValue
            );

        element.textContent =
            value;

        if (progress < 1) {

            requestAnimationFrame(
                update
            );

        } else {

            element.textContent =
                finalValue;

        }

    }

    requestAnimationFrame(update);

}


// ======================================
// LOAD USERS
// ======================================

async function loadUsers() {

    const container =
        document.getElementById(
            "usersContainer"
        );

    if (!container) {
        return;
    }

    showLoading(
        container,
        "Loading users..."
    );

    try {

        const users =
            await adminFetch(
                "/api/admin/users"
            );

        if (
            !Array.isArray(users) ||
            users.length === 0
        ) {

            showEmpty(
                container,
                "👥",
                "No users found"
            );

            return;

        }

        let html = `

            <div class="table-wrapper">

                <table class="admin-table users-table">

                    <thead>

                        <tr>

                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

        `;


        users.forEach(
            currentUser => {

                const role =
                    String(
                        currentUser.role || ""
                    )
                        .trim()
                        .toLowerCase();

                const roleClass =
                    role === "admin"
                        ? "role-admin"
                        : role === "organizer"
                            ? "role-organizer"
                            : "role-user";


                html += `

                    <tr>

                        <td>

                            <span class="id-badge">
                                ${escapeHtml(
                                    currentUser.id
                                )}
                            </span>

                        </td>


                        <td>

                            <strong>
                                ${escapeHtml(
                                    currentUser.name ||
                                    "N/A"
                                )}
                            </strong>

                        </td>


                        <td>

                            <span class="email-cell">
                                ${escapeHtml(
                                    currentUser.email ||
                                    "N/A"
                                )}
                            </span>

                        </td>


                        <td>

                            <span
                                class="role-badge ${roleClass}"
                            >
                                ${escapeHtml(
                                    currentUser.role ||
                                    "N/A"
                                )}
                            </span>

                        </td>


                        <td>

                            <div class="action-buttons">

                                <button
                                    type="button"
                                    class="action-btn role-btn"
                                    onclick="changeUserRole(${currentUser.id})"
                                >
                                    ⚙ Role
                                </button>


                                ${
                                    role !== "admin"
                                        ? `

                                        <button
                                            type="button"
                                            class="action-btn delete-btn"
                                            onclick="deleteUser(${currentUser.id})"
                                        >
                                            🗑 Delete
                                        </button>

                                        `
                                        : ""
                                }

                            </div>

                        </td>

                    </tr>

                `;

            }
        );


        html += `

                    </tbody>

                </table>

            </div>

        `;


        container.innerHTML =
            html;

        addRowInteractions(
            container
        );

    } catch (error) {

        console.error(
            "LOAD USERS ERROR:",
            error
        );

        container.innerHTML =
            `

            <div class="error">

                Failed to load users:

                ${escapeHtml(
                    error.message
                )}

            </div>

            `;

    }

}


// ======================================
// CHANGE USER ROLE
// ======================================

async function changeUserRole(
    userId
) {

    const role =
        prompt(
            "Enter new role:\n\nuser\norganizer"
        );

    if (!role) {
        return;
    }

    const newRole =
        role
            .trim()
            .toLowerCase();

    if (
        newRole !== "user" &&
        newRole !== "organizer"
    ) {

        alert(
            "Role must be either user or organizer."
        );

        return;

    }

    try {

        const data =
            await adminFetch(
                `/api/admin/users/${userId}/role`,
                {

                    method: "PUT",

                    body:
                        JSON.stringify({
                            role: newRole
                        })

                }
            );

        alert(
            data.message ||
            "User role updated successfully."
        );

        await loadUsers();

    } catch (error) {

        alert(
            error.message
        );

    }

}


// ======================================
// DELETE USER
// ======================================

async function deleteUser(
    userId
) {

    const confirmed =
        confirm(
            "Are you sure you want to delete this user?"
        );

    if (!confirmed) {
        return;
    }

    try {

        const data =
            await adminFetch(
                `/api/admin/users/${userId}`,
                {
                    method: "DELETE"
                }
            );

        alert(
            data.message ||
            "User deleted successfully."
        );

        await loadUsers();

        await loadStats();

    } catch (error) {

        alert(
            error.message
        );

    }

}


// ======================================
// LOAD EVENTS
// ======================================

async function loadEvents() {

    const container =
        document.getElementById(
            "eventsContainer"
        );

    if (!container) {
        return;
    }

    showLoading(
        container,
        "Loading events..."
    );

    try {

        const events =
            await adminFetch(
                "/api/admin/events"
            );

        if (
            !Array.isArray(events) ||
            events.length === 0
        ) {

            showEmpty(
                container,
                "📅",
                "No events found"
            );

            return;

        }


        let html = `

            <div class="table-wrapper events-table-wrapper">

                <table class="admin-table events-table">

                    <thead>

                        <tr>

                            <th>ID</th>
                            <th>Event</th>
                            <th>Category</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Venue</th>
                            <th>Price</th>
                            <th>Seats</th>
                            <th>Organizer</th>
                            <th>Status</th>
                            <th>Actions</th>

                        </tr>

                    </thead>

                    <tbody>

        `;


        events.forEach(
            event => {

                const status =
                    String(
                        event.status || ""
                    )
                        .trim()
                        .toLowerCase();


                const statusClass =
                    status === "cancelled"
                        ? "status-cancelled"
                        : "status-active";


                const actionButton =
                    status === "cancelled"

                        ? `

                            <button
                                type="button"
                                class="action-btn activate-btn"
                                onclick="activateEvent(${event.id})"
                            >
                                ✓ Activate
                            </button>

                        `

                        : `

                            <button
                                type="button"
                                class="action-btn cancel-btn"
                                onclick="cancelEvent(${event.id})"
                            >
                                ⏸ Cancel
                            </button>

                        `;


                const availableSeats =
                    Number(
                        event.available_seats || 0
                    );


                const totalSeats =
                    Number(
                        event.total_seats || 0
                    );


                let seatClass =
                    "seats-normal";


                if (
                    totalSeats > 0 &&
                    availableSeats /
                        totalSeats <=
                        0.2
                ) {

                    seatClass =
                        "seats-low";

                }


                html += `

                    <tr>

                        <td>

                            <span class="id-badge">
                                ${escapeHtml(
                                    event.id
                                )}
                            </span>

                        </td>


                        <td class="event-title-cell">

                            <strong>
                                ${escapeHtml(
                                    event.title ||
                                    "N/A"
                                )}
                            </strong>

                        </td>


                        <td>

                            <span class="category-badge">
                                ${escapeHtml(
                                    event.category ||
                                    "N/A"
                                )}
                            </span>

                        </td>


                        <td>

                            ${formatTableDate(
                                event.event_date
                            )}

                        </td>


                        <td>

                            ${formatTime12Hour(
                                event.event_time
                            )}

                        </td>


                        <td class="venue-cell">

                            ${escapeHtml(
                                event.venue ||
                                "N/A"
                            )}

                        </td>


                        <td>

                            <strong class="price-text">

                                ${formatMoney(
                                    event.ticket_price
                                )}

                            </strong>

                        </td>


                        <td>

                            <span
                                class="seat-badge ${seatClass}"
                            >

                                ${
                                    event.available_seats ||
                                    0
                                }

                                /

                                ${
                                    event.total_seats ||
                                    0
                                }

                            </span>

                        </td>


                        <td>

                            <span class="organizer-cell">
                                ${escapeHtml(
                                    event.organizer_name ||
                                    "N/A"
                                )}
                            </span>

                        </td>


                        <td>

                            <span
                                class="status-badge ${statusClass}"
                            >

                                <span class="status-dot"></span>

                                ${escapeHtml(
                                    formatStatus(
                                        event.status
                                    )
                                )}

                            </span>

                        </td>


                        <td>

                            <div
                                class="action-buttons event-actions"
                            >

                                <button
                                    type="button"
                                    class="action-btn edit-btn"
                                    onclick="editEvent(${event.id})"
                                >
                                    ✎ Edit
                                </button>


                                ${actionButton}


                                <button
                                    type="button"
                                    class="action-btn delete-btn"
                                    onclick="deleteEvent(${event.id})"
                                >
                                    🗑 Delete
                                </button>

                            </div>

                        </td>

                    </tr>

                `;

            }
        );


        html += `

                    </tbody>

                </table>

            </div>

        `;


        container.innerHTML =
            html;

        addRowInteractions(
            container
        );

    } catch (error) {

        console.error(
            "LOAD EVENTS ERROR:",
            error
        );

        container.innerHTML =
            `

            <div class="error">

                Failed to load events:

                ${escapeHtml(
                    error.message
                )}

            </div>

            `;

    }

}


// ======================================
// EDIT EVENT
// ======================================

async function editEvent(
    eventId
) {

    try {

        const events =
            await adminFetch(
                "/api/admin/events"
            );


        const event =
            events.find(
                item =>
                    Number(item.id) ===
                    Number(eventId)
            );


        if (!event) {

            alert(
                "Event not found."
            );

            return;

        }


        const title =
            prompt(
                "Event Title:",
                event.title || ""
            );

        if (title === null) {
            return;
        }


        const description =
            prompt(
                "Description:",
                event.description || ""
            );

        if (description === null) {
            return;
        }


        const category =
            prompt(
                "Category:",
                event.category || ""
            );

        if (category === null) {
            return;
        }


        const currentDate =
            formatDateForEdit(
                event.event_date
            );


        const dateInput =
            prompt(
                "Event Date (DD/MM/YYYY):",
                currentDate
            );

        if (dateInput === null) {
            return;
        }


        const databaseDate =
            convertDateToDatabaseFormat(
                dateInput
            );


        if (!databaseDate) {

            alert(
                "Invalid date format.\n\n" +
                "Please use DD/MM/YYYY\n" +
                "Example: 25/12/2026"
            );

            return;

        }


        const currentTime =
            formatTime12Hour(
                event.event_time
            );


        const timeInput =
            prompt(
                "Event Time (hh:mm AM/PM):",
                currentTime
            );

        if (timeInput === null) {
            return;
        }


        const databaseTime =
            convertTimeToDatabaseFormat(
                timeInput
            );


        if (!databaseTime) {

            alert(
                "Invalid time format.\n\n" +
                "Please use hh:mm AM/PM\n" +
                "Example: 07:30 PM"
            );

            return;

        }


        const venue =
            prompt(
                "Venue:",
                event.venue || ""
            );

        if (venue === null) {
            return;
        }


        const currentPrice =
            Number(
                event.ticket_price || 0
            );


        const priceInput =
            prompt(
                "Ticket Price:",
                currentPrice
            );

        if (priceInput === null) {
            return;
        }


        const price =
            Number(priceInput);


        if (
            Number.isNaN(price) ||
            price < 0
        ) {

            alert(
                "Please enter a valid ticket price."
            );

            return;

        }


        const currentTotalSeats =
            Number(
                event.total_seats || 0
            );


        const currentAvailableSeats =
            Number(
                event.available_seats || 0
            );


        const bookedSeats =
            currentTotalSeats -
            currentAvailableSeats;


        const seatsInput =
            prompt(
                `Total Seats:\n\nCurrently booked: ${bookedSeats}`,
                currentTotalSeats
            );


        if (seatsInput === null) {
            return;
        }


        const seats =
            Number(seatsInput);


        if (
            !Number.isInteger(seats) ||
            seats <= 0
        ) {

            alert(
                "Total seats must be a positive whole number."
            );

            return;

        }


        if (seats < bookedSeats) {

            alert(
                `You cannot set total seats below ${bookedSeats}.\n\n` +
                `${bookedSeats} seat(s) are already booked.`
            );

            return;

        }


        const image =
            prompt(
                "Image URL:",
                event.image || ""
            );

        if (image === null) {
            return;
        }


        const currentStatus =
            event.status ||
            "active";


        const statusInput =
            prompt(
                "Status (active/cancelled):",
                currentStatus
            );


        if (statusInput === null) {
            return;
        }


        const status =
            statusInput
                .trim()
                .toLowerCase();


        if (
            status !== "active" &&
            status !== "cancelled"
        ) {

            alert(
                "Status must be either active or cancelled."
            );

            return;

        }


        if (
            !title.trim() ||
            !category.trim() ||
            !databaseDate ||
            !databaseTime ||
            !venue.trim()
        ) {

            alert(
                "Please fill in all required event information."
            );

            return;

        }


        const data =
            await adminFetch(
                `/api/events/${eventId}`,
                {

                    method: "PUT",

                    body:
                        JSON.stringify({

                            title:
                                title.trim(),

                            description:
                                description.trim(),

                            category:
                                category.trim(),

                            date:
                                databaseDate,

                            time:
                                databaseTime,

                            location:
                                venue.trim(),

                            price:
                                price,

                            total_seats:
                                seats,

                            image:
                                image.trim(),

                            status:
                                status

                        })

                }
            );


        alert(
            data.message ||
            "Event updated successfully."
        );


        await loadEvents();

        await loadStats();

    } catch (error) {

        console.error(
            "EDIT EVENT ERROR:",
            error
        );

        alert(
            error.message ||
            "Failed to update event."
        );

    }

}


// ======================================
// DELETE EVENT
// ======================================

async function deleteEvent(
    eventId
) {

    const confirmed =
        confirm(
            "Are you sure you want to delete this event?\n\n" +
            "Events with existing bookings cannot be deleted."
        );


    if (!confirmed) {
        return;
    }


    try {

        const data =
            await adminFetch(
                `/api/events/${eventId}`,
                {
                    method: "DELETE"
                }
            );


        alert(
            data.message ||
            "Event deleted successfully."
        );


        await loadEvents();

        await loadStats();

    } catch (error) {

        alert(
            error.message
        );

    }

}


// ======================================
// CANCEL EVENT
// ======================================

async function cancelEvent(
    eventId
) {

    const confirmed =
        confirm(
            "Are you sure you want to cancel this event?"
        );


    if (!confirmed) {
        return;
    }


    try {

        const data =
            await adminFetch(
                `/api/events/${eventId}/cancel`,
                {

                    method: "PUT",

                    body:
                        JSON.stringify({})

                }
            );


        alert(
            data.message ||
            "Event cancelled successfully."
        );


        await loadEvents();

        await loadStats();

    } catch (error) {

        alert(
            error.message
        );

    }

}


// ======================================
// ACTIVATE EVENT
// ======================================

async function activateEvent(
    eventId
) {

    const confirmed =
        confirm(
            "Activate this event?"
        );


    if (!confirmed) {
        return;
    }


    try {

        const data =
            await adminFetch(
                `/api/events/${eventId}/activate`,
                {

                    method: "PUT",

                    body:
                        JSON.stringify({})

                }
            );


        alert(
            data.message ||
            "Event activated successfully."
        );


        await loadEvents();

        await loadStats();

    } catch (error) {

        alert(
            error.message
        );

    }

}


// ======================================
// LOAD BOOKINGS
// ======================================

async function loadBookings() {

    const container =
        document.getElementById(
            "bookingsContainer"
        );


    if (!container) {
        return;
    }


    showLoading(
        container,
        "Loading bookings..."
    );


    try {

        const bookings =
            await adminFetch(
                "/api/admin/bookings"
            );


        if (
            !Array.isArray(bookings) ||
            bookings.length === 0
        ) {

            showEmpty(
                container,
                "📋",
                "No bookings found"
            );

            return;

        }


        let html = `

            <div class="table-wrapper">

                <table class="admin-table bookings-table">

                    <thead>

                        <tr>

                            <th>ID</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Event</th>
                            <th>Qty</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Booking Date</th>

                        </tr>

                    </thead>

                    <tbody>

        `;


        bookings.forEach(
            booking => {

                html += `

                    <tr>

                        <td>

                            <span class="id-badge">
                                ${escapeHtml(
                                    booking.id
                                )}
                            </span>

                        </td>


                        <td>

                            <strong>
                                ${escapeHtml(
                                    booking.user_name ||
                                    "N/A"
                                )}
                            </strong>

                        </td>


                        <td>
                            ${escapeHtml(
                                booking.user_email ||
                                "N/A"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                booking.event_title ||
                                "N/A"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                booking.quantity ||
                                0
                            )}
                        </td>


                        <td>

                            <strong class="price-text">

                                ${formatMoney(
                                    booking.total_amount
                                )}

                            </strong>

                        </td>


                        <td>

                            <span class="data-status">

                                ${escapeHtml(
                                    booking.booking_status ||
                                    "N/A"
                                )}

                            </span>

                        </td>


                        <td>

                            ${escapeHtml(
                                booking.booking_date ||
                                "N/A"
                            )}

                        </td>

                    </tr>

                `;

            }
        );


        html += `

                    </tbody>

                </table>

            </div>

        `;


        container.innerHTML =
            html;

        addRowInteractions(
            container
        );

    } catch (error) {

        console.error(
            "LOAD BOOKINGS ERROR:",
            error
        );

        container.innerHTML =
            `

            <div class="error">

                Failed to load bookings:

                ${escapeHtml(
                    error.message
                )}

            </div>

            `;

    }

}


// ======================================
// LOAD PAYMENTS
// ======================================

async function loadPayments() {

    const container =
        document.getElementById(
            "paymentsContainer"
        );


    if (!container) {
        return;
    }


    showLoading(
        container,
        "Loading payments..."
    );


    try {

        const payments =
            await adminFetch(
                "/api/admin/payments"
            );


        if (
            !Array.isArray(payments) ||
            payments.length === 0
        ) {

            showEmpty(
                container,
                "💳",
                "No payments found"
            );

            return;

        }


        let html = `

            <div class="table-wrapper">

                <table class="admin-table payments-table">

                    <thead>

                        <tr>

                            <th>ID</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Event</th>
                            <th>Amount</th>
                            <th>Method</th>
                            <th>Transaction ID</th>
                            <th>Status</th>
                            <th>Payment Date</th>

                        </tr>

                    </thead>

                    <tbody>

        `;


        payments.forEach(
            payment => {

                html += `

                    <tr>

                        <td>

                            <span class="id-badge">
                                ${escapeHtml(
                                    payment.id
                                )}
                            </span>

                        </td>


                        <td>

                            <strong>
                                ${escapeHtml(
                                    payment.user_name ||
                                    "N/A"
                                )}
                            </strong>

                        </td>


                        <td>
                            ${escapeHtml(
                                payment.user_email ||
                                "N/A"
                            )}
                        </td>


                        <td>
                            ${escapeHtml(
                                payment.event_title ||
                                "N/A"
                            )}
                        </td>


                        <td>

                            <strong class="price-text">

                                ${formatMoney(
                                    payment.amount
                                )}

                            </strong>

                        </td>


                        <td>
                            ${escapeHtml(
                                payment.payment_method ||
                                "N/A"
                            )}
                        </td>


                        <td>

                            <code class="transaction-code">

                                ${escapeHtml(
                                    payment.transaction_id ||
                                    "N/A"
                                )}

                            </code>

                        </td>


                        <td>

                            <span class="data-status">

                                ${escapeHtml(
                                    payment.payment_status ||
                                    "N/A"
                                )}

                            </span>

                        </td>


                        <td>

                            ${escapeHtml(
                                payment.payment_date ||
                                "N/A"
                            )}

                        </td>

                    </tr>

                `;

            }
        );


        html += `

                    </tbody>

                </table>

            </div>

        `;


        container.innerHTML =
            html;

        addRowInteractions(
            container
        );

    } catch (error) {

        console.error(
            "LOAD PAYMENTS ERROR:",
            error
        );

        container.innerHTML =
            `

            <div class="error">

                Failed to load payments:

                ${escapeHtml(
                    error.message
                )}

            </div>

            `;

    }

}


// ======================================
// LOAD TICKETS
// ======================================

async function loadTickets() {

    const container =
        document.getElementById(
            "ticketsContainer"
        );


    if (!container) {
        return;
    }


    showLoading(
        container,
        "Loading tickets..."
    );


    try {

        const tickets =
            await adminFetch(
                "/api/admin/tickets"
            );


        if (
            !Array.isArray(tickets) ||
            tickets.length === 0
        ) {

            showEmpty(
                container,
                "🎟️",
                "No tickets found"
            );

            return;

        }


        let html = `

            <div class="table-wrapper">

                <table class="admin-table tickets-table">

                    <thead>

                        <tr>

                            <th>ID</th>
                            <th>Ticket Code</th>
                            <th>Booking ID</th>
                            <th>User</th>
                            <th>Email</th>
                            <th>Event</th>
                            <th>Qty</th>
                            <th>Status</th>
                            <th>Created</th>

                        </tr>

                    </thead>

                    <tbody>

        `;


        tickets.forEach(
            ticket => {

                html += `

                    <tr>

                        <td>

                            <span class="id-badge">
                                ${escapeHtml(
                                    ticket.id
                                )}
                            </span>

                        </td>


                        <td>

                            <code class="ticket-code">

                                ${escapeHtml(
                                    ticket.ticket_code ||
                                    "N/A"
                                )}

                            </code>

                        </td>


                        <td>

                            ${escapeHtml(
                                ticket.booking_id ||
                                "N/A"
                            )}

                        </td>


                        <td>

                            <strong>
                                ${escapeHtml(
                                    ticket.user_name ||
                                    "N/A"
                                )}
                            </strong>

                        </td>


                        <td>

                            ${escapeHtml(
                                ticket.user_email ||
                                "N/A"
                            )}

                        </td>


                        <td>

                            ${escapeHtml(
                                ticket.event_title ||
                                "N/A"
                            )}

                        </td>


                        <td>

                            ${escapeHtml(
                                ticket.quantity ||
                                0
                            )}

                        </td>


                        <td>

                            <span class="data-status">

                                ${escapeHtml(
                                    ticket.booking_status ||
                                    "N/A"
                                )}

                            </span>

                        </td>


                        <td>

                            ${escapeHtml(
                                ticket.created_at ||
                                "N/A"
                            )}

                        </td>

                    </tr>

                `;

            }
        );


        html += `

                    </tbody>

                </table>

            </div>

        `;


        container.innerHTML =
            html;

        addRowInteractions(
            container
        );

    } catch (error) {

        console.error(
            "LOAD TICKETS ERROR:",
            error
        );

        container.innerHTML =
            `

            <div class="error">

                Failed to load tickets:

                ${escapeHtml(
                    error.message
                )}

            </div>

            `;

    }

}


// ======================================
// ROW INTERACTION
// ======================================

function addRowInteractions(
    container
) {

    const rows =
        container.querySelectorAll(
            "tbody tr"
        );


    rows.forEach(
        row => {

            row.addEventListener(
                "mouseenter",
                () => {

                    row.classList.add(
                        "row-active"
                    );

                }
            );


            row.addEventListener(
                "mouseleave",
                () => {

                    row.classList.remove(
                        "row-active"
                    );

                }
            );

        }
    );

}


// ======================================
// BUTTON CLICK FEEDBACK
// ======================================

document.addEventListener(
    "click",
    event => {

        const button =
            event.target.closest(
                ".action-btn"
            );


        if (!button) {
            return;
        }


        button.classList.add(
            "button-clicked"
        );


        setTimeout(
            () => {

                button.classList.remove(
                    "button-clicked"
                );

            },
            250
        );

    }
);


// ======================================
// LOGOUT
// ======================================

function logout() {

    localStorage.removeItem(
        "token"
    );

    localStorage.removeItem(
        "user"
    );

    window.location.href =
        "login.html";

}


// ======================================
// INITIAL LOAD
// ======================================

document.addEventListener(
    "DOMContentLoaded",
    async () => {

        await loadStats();

        await loadUsers();

        await loadEvents();

        await loadBookings();

        await loadPayments();

        await loadTickets();

    }
);